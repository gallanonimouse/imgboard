<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

require_once __DIR__ . '/../include/config.php';
require_once __DIR__ . '/../include/functions.php';

// Admin password – CHANGE THIS IN PRODUCTION!
$ADMIN_PASSWORD = SECRET_KEY;

$baseDir = __DIR__ . '/..';
$banFile = $baseDir . '/boardban.json';
$notesFileName = defined('IP_NOTES_FILE') && trim((string)IP_NOTES_FILE) !== ''
    ? ltrim(str_replace('\\', '/', trim((string)IP_NOTES_FILE)), '/')
    : 'ipnotes.json';
$notesFile = $baseDir . '/' . $notesFileName;
$threadsDir = $baseDir . '/threads';
$logFile = $threadsDir . '/log.txt';
$configFile = __DIR__ . '/../include/config.php';
$configBackupsDir = __DIR__ . '/config-backups';

$message = '';
$messageType = 'success';
$configMessage = '';
$configMessageType = 'success';

/* ---------- Helpers ---------- */

function loadJsonArray($path) {
    if (!file_exists($path)) {
        return [];
    }

    $data = json_decode(file_get_contents($path), true);
    return is_array($data) ? $data : [];
}

function saveJsonArray($path, array $data) {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return false;
    }

    return file_put_contents($path, $json) !== false;
}

function ensureDataFile($path) {
    $dir = dirname($path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }

    if (!file_exists($path)) {
        @file_put_contents($path, "[]\n");
    }
}

function deleteDir($dir) {
    foreach (scandir($dir) as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $dir . '/' . $item;
        if (is_dir($path)) {
            deleteDir($path);
        } else {
            @unlink($path);
        }
    }
    @rmdir($dir);
}

// --- Helper: resolve threadid + timestamp to IP ---
function resolveThreadidToIP($threadid, $timestamp, $logFilePath) {
    if (!file_exists($logFilePath)) {
        return null;
    }

    $lines = file($logFilePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $parts = explode(':', $line);
        // Format: timestamp:type:threadid:ip_address
        if (count($parts) >= 4 && $parts[2] === $threadid && $parts[0] === $timestamp) {
            try {
                $ip = decryptText($parts[3], SECRET_KEY);
                return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : null;
            } catch (Exception $e) {
                return null;
            }
        }
    }
    return null;
}

ensureDataFile($banFile);
ensureDataFile($notesFile);

$banned = loadJsonArray($banFile);
$notes = loadJsonArray($notesFile);

/* ---------- Login ---------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_password'])) {
    if (hash_equals((string)$ADMIN_PASSWORD, (string)$_POST['login_password'])) {
        $_SESSION['logged_in'] = true;
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

    $message = 'Invalid password.';
    $messageType = 'error';
}

if (empty($_SESSION['logged_in'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Moderator Login - Imageboard</title>
        <link rel="stylesheet" href="../style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
    </head>
    <body>
        <div class="container moderator-panel">
            <h1>Moderator Login</h1>

            <div class="mod-card mod-login-card">
                <?php if ($message !== ''): ?>
                    <div class="mod-flash inline <?= $messageType === 'error' ? 'error' : 'success' ?>">
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="index.php">
                    <div class="form-group">
                        <label for="login_password">Admin password</label>
                        <input type="password" id="login_password" name="login_password" placeholder="Password"
                               autocomplete="current-password" required autofocus>
                    </div>
                    <button type="submit" class="mod-button">Log In</button>
                </form>
            </div>

            <p class="mod-login-back">
                <a class="mod-link" href="../index.php">Back to Board</a>
            </p>
        </div>
    </body>
    </html>
    <?php
    exit;
}

/* ---------- Flash messages after redirects ---------- */

if (isset($_SESSION['mod_flash']) && is_array($_SESSION['mod_flash'])) {
    $message = (string)($_SESSION['mod_flash']['message'] ?? '');
    $messageType = ($_SESSION['mod_flash']['type'] ?? 'success') === 'error' ? 'error' : 'success';
    unset($_SESSION['mod_flash']);
}

if (isset($_SESSION['mod_config_flash']) && is_array($_SESSION['mod_config_flash'])) {
    $configMessage = (string)($_SESSION['mod_config_flash']['message'] ?? '');
    $configMessageType = ($_SESSION['mod_config_flash']['type'] ?? 'success') === 'error' ? 'error' : 'success';
    unset($_SESSION['mod_config_flash']);
}

/* ---------- Edit include/config.php ---------- */

$configContent = file_exists($configFile) ? (string)file_get_contents($configFile) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_config'])) {
    $newConfig = $_POST['config_content'] ?? '';
    $configError = null;

    if (!is_string($newConfig) || trim($newConfig) === '') {
        $configError = 'Configuration content cannot be empty.';
    } elseif (strpos(ltrim($newConfig), '<?php') !== 0) {
        $configError = 'The configuration must start with <?php.';
    } else {
        // Validate PHP syntax without executing the file
        try {
            token_get_all($newConfig, TOKEN_PARSE);
        } catch (ParseError $e) {
            $configError = 'PHP syntax error on line ' . $e->getLine() . ': ' . $e->getMessage();
        }

        if ($configError === null && !preg_match('/define\s*\(\s*[\'"]SECRET_KEY[\'"]/', $newConfig)) {
            $configError = 'The configuration must still define SECRET_KEY.';
        }
    }

    if ($configError !== null) {
        $configMessage = $configError;
        $configMessageType = 'error';
        // Keep the submitted text so the moderator does not lose their edits
        $configContent = is_string($newConfig) ? $newConfig : $configContent;
    } elseif (!is_file($configFile) || !is_writable($configFile)) {
        $configMessage = 'The configuration file is not writable. Check file permissions.';
        $configMessageType = 'error';
        $configContent = $newConfig;
    } else {
        if (!is_dir($configBackupsDir)) {
            @mkdir($configBackupsDir, 0755, true);
        }

        $backupPath = $configBackupsDir . '/config-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.php';
        $backupCreated = @copy($configFile, $backupPath);

        if (!$backupCreated) {
            $configMessage = 'Could not create a configuration backup. The file was not changed.';
            $configMessageType = 'error';
            $configContent = $newConfig;
        } else {
            // Keep only the 20 most recent backups
            $backups = glob($configBackupsDir . '/config-*.php');
            if (is_array($backups) && count($backups) > 20) {
                usort($backups, function ($a, $b) {
                    return filemtime($a) <=> filemtime($b);
                });
                foreach (array_slice($backups, 0, count($backups) - 20) as $oldBackup) {
                    @unlink($oldBackup);
                }
            }

            if (@file_put_contents($configFile, $newConfig, LOCK_EX) === false) {
                $configMessage = 'Could not save the configuration file. A backup is available in moderator/config-backups/.';
                $configMessageType = 'error';
                $configContent = $newConfig;
            } else {
                if (function_exists('opcache_invalidate')) {
                    @opcache_invalidate($configFile, true);
                }

                $_SESSION['mod_config_flash'] = [
                    'type' => 'success',
                    'message' => 'Configuration saved. A backup was created in moderator/config-backups/.',
                ];
                header('Location: ' . $_SERVER['PHP_SELF'] . '#config');
                exit;
            }
        }
    }
}

/* ---------- Ban IP / Thread ID ---------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ban_action'])) {
    $resolvedIp = null;
    $banSource = '';

    $threadid = trim($_POST['add_threadid'] ?? '');
    $timestamp = trim($_POST['add_timestamp'] ?? '');
    $ipInput = trim($_POST['add_ip'] ?? '');
    $reason = trim($_POST['reason'] ?? '');

    if ($threadid !== '' && $timestamp !== '') {
        $resolvedIp = resolveThreadidToIP($threadid, $timestamp, $logFile);
        if ($resolvedIp) {
            $banSource = " (resolved from Thread ID: {$threadid}, Timestamp: {$timestamp})";
        } else {
            $message = "No matching entry found for Thread ID '{$threadid}' with Timestamp '{$timestamp}'.";
            $messageType = 'error';
        }
    } elseif ($threadid !== '' && $timestamp === '') {
        $message = 'Please enter a timestamp for the selected Thread ID.';
        $messageType = 'error';
    } elseif ($timestamp !== '' && $threadid === '') {
        $message = 'Please select a Thread ID for the entered Timestamp.';
        $messageType = 'error';
    } elseif ($ipInput !== '') {
        if (!filter_var($ipInput, FILTER_VALIDATE_IP)) {
            $message = 'Invalid IP address.';
            $messageType = 'error';
        } else {
            $resolvedIp = $ipInput;
        }
    } else {
        $message = 'Please provide an IP address or both Thread ID and Timestamp.';
        $messageType = 'error';
    }

    if ($resolvedIp) {
        $alreadyBanned = false;
        foreach ($banned as $entry) {
            if (($entry['ip'] ?? '') === $resolvedIp) {
                $alreadyBanned = true;
                break;
            }
        }

        if ($alreadyBanned) {
            $message = "IP {$resolvedIp} is already banned{$banSource}.";
            $messageType = 'error';
        } else {
            $banned[] = [
                'ip' => $resolvedIp,
                'reason' => $reason ?: 'No reason given',
                'banned_at' => date('Y-m-d H:i:s'),
                'source' => $threadid !== '' ? 'threadid' : 'ip',
                'threadid' => $threadid,
                'timestamp' => $timestamp,
            ];

            if (saveJsonArray($banFile, $banned)) {
                $message = "IP {$resolvedIp} has been banned{$banSource}.";
            } else {
                array_pop($banned);
                $message = 'Could not save the ban list. Check file permissions.';
                $messageType = 'error';
            }
        }
    }
}

/* ---------- IP notes ---------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_note'])) {
    $noteIp = trim($_POST['note_ip'] ?? '');
    $noteComment = trim($_POST['note_comment'] ?? '');

    if (!filter_var($noteIp, FILTER_VALIDATE_IP)) {
        $message = 'Please provide a valid IP address for the note.';
        $messageType = 'error';
    } elseif ($noteComment === '') {
        $message = 'Please enter the note text.';
        $messageType = 'error';
    } else {
        $notes[] = [
            'id' => bin2hex(random_bytes(8)),
            'ip' => $noteIp,
            'comment' => $noteComment,
            'created_at' => date('Y-m-d H:i:s'),
        ];

        if (saveJsonArray($notesFile, $notes)) {
            $message = "Note for IP {$noteIp} has been saved.";
        } else {
            array_pop($notes);
            $message = 'Could not save the note. Check file permissions.';
            $messageType = 'error';
        }
    }
}

/* ---------- Delete message ---------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_message'])) {
    $threadid = trim($_POST['delete_msg_threadid'] ?? '');
    $msgTimestamp = trim($_POST['delete_msg_timestamp'] ?? '');

    if ($threadid !== '' && $msgTimestamp !== '') {
        $folderName = basename($threadid); // Prevent directory traversal
        $dataFilePath = $threadsDir . '/' . $folderName . '/data.json';

        if (file_exists($dataFilePath)) {
            $threadData = json_decode(file_get_contents($dataFilePath), true);
            if (is_array($threadData) && isset($threadData['messages']) && is_array($threadData['messages'])) {
                $initialCount = count($threadData['messages']);

                $threadData['messages'] = array_values(array_filter($threadData['messages'], function ($msg) use ($msgTimestamp) {
                    return (string)($msg['timestamp'] ?? '') !== (string)$msgTimestamp;
                }));

                $deletedCount = $initialCount - count($threadData['messages']);

                if ($deletedCount > 0) {
                    $json = json_encode($threadData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                    if ($json !== false && file_put_contents($dataFilePath, $json) !== false) {
                        $message = "{$deletedCount} message(s) with timestamp '{$msgTimestamp}' deleted from thread '{$folderName}'.";
                    } else {
                        $message = "Could not save changes to thread '{$folderName}'.";
                        $messageType = 'error';
                    }
                } else {
                    $message = "No message found with timestamp '{$msgTimestamp}' in thread '{$folderName}'.";
                    $messageType = 'error';
                }
            } else {
                $message = "Invalid data.json format in thread '{$folderName}'.";
                $messageType = 'error';
            }
        } else {
            $message = "Thread '{$folderName}' data.json not found.";
            $messageType = 'error';
        }
    } else {
        $message = 'Please select a thread and provide a message timestamp.';
        $messageType = 'error';
    }
}

/* ---------- Unban IP ---------- */

if (isset($_GET['remove_ip'])) {
    $ipToRemove = $_GET['remove_ip'];
    $newBanned = [];
    $found = false;

    foreach ($banned as $entry) {
        if (($entry['ip'] ?? '') !== $ipToRemove) {
            $newBanned[] = $entry;
        } else {
            $found = true;
        }
    }

    if ($found) {
        if (saveJsonArray($banFile, $newBanned)) {
            $banned = $newBanned;
            $message = "IP {$ipToRemove} has been unbanned.";
        } else {
            $message = 'Could not save the ban list. Check file permissions.';
            $messageType = 'error';
        }
    } else {
        $message = 'IP not found in ban list.';
        $messageType = 'error';
    }
}

/* ---------- Remove IP note ---------- */

if (isset($_GET['remove_note'])) {
    $noteId = (string)$_GET['remove_note'];
    $newNotes = [];
    $removed = false;

    foreach ($notes as $note) {
        if ((string)($note['id'] ?? '') !== $noteId) {
            $newNotes[] = $note;
        } else {
            $removed = true;
        }
    }

    if ($removed) {
        if (saveJsonArray($notesFile, $newNotes)) {
            $notes = $newNotes;
            $message = 'Note has been deleted.';
        } else {
            $message = 'Could not save the note file. Check file permissions.';
            $messageType = 'error';
        }
    } else {
        $message = 'Note not found.';
        $messageType = 'error';
    }
}

/* ---------- Delete thread folder ---------- */

if (isset($_GET['delete_thread'])) {
    $folderName = basename($_GET['delete_thread']);
    $folderPath = $threadsDir . '/' . $folderName;

    if (is_dir($folderPath)) {
        deleteDir($folderPath);
        $message = "Thread folder '{$folderName}' has been deleted.";
    } else {
        $message = 'Thread folder not found.';
        $messageType = 'error';
    }
}

/* ---------- Logout ---------- */

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

/* ---------- Data for the view ---------- */

$threadFolders = [];
if (is_dir($threadsDir)) {
    foreach (scandir($threadsDir) as $item) {
        if ($item !== '.' && $item !== '..' && is_dir($threadsDir . '/' . $item)) {
            $threadFolders[] = $item;
        }
    }
    sort($threadFolders, SORT_NATURAL | SORT_FLAG_CASE);
} else {
    $threadFolders = null;
}

$notesForDisplay = $notes;
usort($notesForDisplay, function ($a, $b) {
    return strcmp((string)($b['created_at'] ?? ''), (string)($a['created_at'] ?? ''));
});
$bannedIps = array_column($banned, 'ip');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moderator Panel - Imageboard</title>
    <link rel="stylesheet" href="../style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
</head>
<body>
    <div class="container moderator-panel">
        <h1>Moderator Panel</h1>

        <div class="mod-toolbar">
            <span class="mod-toolbar-text">Signed in as moderator</span>
            <div class="mod-toolbar-links">
                <a class="mod-link" href="#config">Configuration</a>
                <a class="mod-link" href="../index.php">Back to Board</a>
                <a class="mod-link danger" href="?logout">Log out</a>
            </div>
        </div>

        <?php if ($message !== ''): ?>
            <div class="mod-flash <?= $messageType === 'error' ? 'error' : 'success' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <!-- Ban Section -->
        <div class="mod-card">
            <h2>Ban an IP Address or Thread ID</h2>

            <form method="post" id="banForm" action="index.php">
                <input type="hidden" name="ban_action" value="1">

                <div class="mod-form-grid">
                    <div class="form-group">
                        <label for="add_ip">IP address</label>
                        <input type="text" id="add_ip" name="add_ip" placeholder="e.g. 192.168.1.100">
                    </div>

                    <div class="form-group">
                        <label for="add_threadid">Thread ID</label>
                        <select id="add_threadid" name="add_threadid">
                            <option value="">-- Select Thread ID --</option>
                            <?php if (is_array($threadFolders) && !empty($threadFolders)): ?>
                                <?php foreach ($threadFolders as $folder): ?>
                                    <option value="<?= htmlspecialchars($folder) ?>"><?= htmlspecialchars($folder) ?></option>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <option value="" disabled>No thread folders found</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="add_timestamp">Timestamp</label>
                        <input type="text" id="add_timestamp" name="add_timestamp" placeholder="e.g. 1780309357">
                        <div class="mod-note">Both Thread ID and Timestamp are required to resolve an IP from log.txt.</div>
                    </div>

                    <div class="form-group full-width">
                        <label for="reason">Reason</label>
                        <input type="text" id="reason" name="reason" placeholder="Optional reason for the ban">
                    </div>
                </div>

                <button type="submit" class="mod-button">Ban IP</button>
            </form>

            <h3>Banned IPs</h3>
            <?php if (!empty($banned)): ?>
                <div class="mod-table-wrap">
                    <table class="mod-table">
                        <thead>
                            <tr>
                                <th>IP Address</th>
                                <th>Reason</th>
                                <th>Banned At</th>
                                <th>Source</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($banned as $entry): ?>
                            <tr>
                                <td><code><?= htmlspecialchars($entry['ip'] ?? '') ?></code></td>
                                <td><?= htmlspecialchars($entry['reason'] ?? '') ?></td>
                                <td><?= htmlspecialchars($entry['banned_at'] ?? '') ?></td>
                                <td>
                                    <?php if (($entry['source'] ?? '') === 'threadid'): ?>
                                        Thread ID: <?= htmlspecialchars($entry['threadid'] ?? 'N/A') ?><br>
                                        <small>TS: <?= htmlspecialchars($entry['timestamp'] ?? 'N/A') ?></small>
                                        <span class="mod-badge thread">threadid</span>
                                    <?php else: ?>
                                        IP<span class="mod-badge ip">ip</span>
                                    <?php endif; ?>
                                </td>
                                <td class="actions">
                                    <a class="mod-link danger"
                                       href="?remove_ip=<?= urlencode($entry['ip'] ?? '') ?>"
                                       onclick="return confirm('Unban this IP?')">Unban</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="mod-empty">No banned IPs.</p>
            <?php endif; ?>
        </div>

        <!-- IP Notes -->
        <div class="mod-card">
            <h2>IP Notes</h2>
            <p class="mod-note">
                Private notes are stored in <code><?= htmlspecialchars($notesFileName) ?></code>.
                They do not ban the IP and are never shown on the board.
            </p>

            <form method="post" action="index.php">
                <div class="mod-form-grid">
                    <div class="form-group">
                        <label for="note_ip">IP address</label>
                        <input type="text" id="note_ip" name="note_ip" placeholder="e.g. 192.168.1.100" required>
                    </div>

                    <div class="form-group full-width">
                        <label for="note_comment">Note</label>
                        <textarea id="note_comment" name="note_comment" placeholder="e.g. Repeated spam, watch this IP." required></textarea>
                    </div>
                </div>

                <button type="submit" name="add_note" value="1" class="mod-button">Save Note</button>
            </form>

            <h3>Saved Notes</h3>
            <?php if (!empty($notesForDisplay)): ?>
                <div class="mod-table-wrap">
                    <table class="mod-table">
                        <thead>
                            <tr>
                                <th>IP Address</th>
                                <th>Note</th>
                                <th>Added</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($notesForDisplay as $note): ?>
                            <tr>
                                <td>
                                    <code><?= htmlspecialchars($note['ip'] ?? '') ?></code>
                                    <?php if (in_array($note['ip'] ?? '', $bannedIps, true)): ?>
                                        <span class="mod-badge banned">banned</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="mod-note-text"><?= nl2br(htmlspecialchars($note['comment'] ?? '')) ?></div>
                                </td>
                                <td><?= htmlspecialchars($note['created_at'] ?? '') ?></td>
                                <td class="actions">
                                    <a class="mod-link danger"
                                       href="?remove_note=<?= urlencode($note['id'] ?? '') ?>"
                                       onclick="return confirm('Delete this note?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="mod-empty">No IP notes saved yet.</p>
            <?php endif; ?>
        </div>

        <!-- Message Management -->
        <div class="mod-card">
            <h2>Delete Message</h2>

            <form method="post" id="deleteMsgForm" action="index.php">
                <div class="mod-form-grid">
                    <div class="form-group">
                        <label for="delete_msg_threadid">Thread ID</label>
                        <select id="delete_msg_threadid" name="delete_msg_threadid" required>
                            <option value="">-- Select Thread ID --</option>
                            <?php if (is_array($threadFolders) && !empty($threadFolders)): ?>
                                <?php foreach ($threadFolders as $folder): ?>
                                    <option value="<?= htmlspecialchars($folder) ?>"><?= htmlspecialchars($folder) ?></option>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <option value="" disabled>No thread folders found</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="delete_msg_timestamp">Message ID (Timestamp)</label>
                        <input type="text" id="delete_msg_timestamp" name="delete_msg_timestamp"
                               placeholder="e.g. 1780993737" required>
                        <div class="mod-note">Enter the timestamp of the message you want to delete.</div>
                    </div>
                </div>

                <button type="submit" name="delete_message" value="1" class="mod-button danger"
                        onclick="return confirm('Are you sure you want to delete this message?');">
                    Delete Message
                </button>
            </form>
        </div>

        <!-- Timestamp Lookup -->
        <div class="mod-card">
            <h2>Lookup by Timestamp</h2>

            <form method="get" action="index.php">
                <div class="mod-form-grid">
                    <div class="form-group">
                        <label for="lookup_ts">Timestamp</label>
                        <input type="text" id="lookup_ts" name="lookup_ts" placeholder="e.g. 1780309357" required>
                    </div>
                </div>
                <button type="submit" class="mod-button">Search</button>
            </form>

            <?php if (isset($_GET['lookup_ts']) && $_GET['lookup_ts'] !== ''): ?>
                <?php
                $lookupTs = trim($_GET['lookup_ts']);
                $results = [];

                if (file_exists($logFile)) {
                    $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                    foreach ($lines as $line) {
                        $parts = explode(':', $line);
                        if (count($parts) >= 4 && $parts[0] === $lookupTs) {
                            try {
                                $ip = decryptText($parts[3], SECRET_KEY);
                            } catch (Exception $e) {
                                $ip = 'Decryption failed';
                            }
                            $results[] = [
                                'timestamp' => $parts[0],
                                'type' => $parts[1],
                                'thread_id' => $parts[2],
                                'ip' => $ip,
                            ];
                        }
                    }
                }
                ?>

                <?php if (!empty($results)): ?>
                    <div class="mod-table-wrap">
                        <table class="mod-table">
                            <thead>
                                <tr><th>Timestamp</th><th>Type</th><th>Thread ID</th><th>IP</th></tr>
                            </thead>
                            <tbody>
                            <?php foreach ($results as $r): ?>
                                <tr>
                                    <td><?= htmlspecialchars($r['timestamp']) ?></td>
                                    <td><?= $r['type'] === 'c' ? 'Create' : 'Post' ?></td>
                                    <td>
                                        <a class="mod-link" href="../index.php?thread=<?= urlencode($r['thread_id']) ?>">
                                            <?= htmlspecialchars($r['thread_id']) ?>
                                        </a>
                                    </td>
                                    <td><code><?= htmlspecialchars($r['ip']) ?></code></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <p class="mod-note"><strong>Total entries:</strong> <?= count($results) ?></p>
                <?php else: ?>
                    <p class="mod-empty">No entries found for timestamp <strong><?= htmlspecialchars($lookupTs) ?></strong>.</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <!-- Thread Folder Management -->
        <div class="mod-card">
            <h2>Thread Folders</h2>
            <p class="mod-note">Stored in <code>../threads/</code>.</p>

            <?php if ($threadFolders === null): ?>
                <p class="mod-empty"><em>Directory <code>../threads/</code> does not exist.</em></p>
            <?php elseif (empty($threadFolders)): ?>
                <p class="mod-empty">No thread folders found.</p>
            <?php else: ?>
                <div class="mod-table-wrap">
                    <table class="mod-table">
                        <thead><tr><th>Folder Name</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php foreach ($threadFolders as $folder): ?>
                            <tr>
                                <td><code><?= htmlspecialchars($folder) ?></code></td>
                                <td class="actions">
                                    <a class="mod-link danger"
                                       href="?delete_thread=<?= urlencode($folder) ?>"
                                       onclick="return confirm('Delete folder \'<?= addslashes(htmlspecialchars($folder)) ?>\' and all its contents? This cannot be undone!');">
                                        Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Configuration Editor -->
        <div class="mod-card" id="config">
            <h2>Configuration</h2>

            <?php if ($configMessage !== ''): ?>
                <div class="mod-flash inline <?= $configMessageType === 'error' ? 'error' : 'success' ?>">
                    <?= htmlspecialchars($configMessage) ?>
                </div>
            <?php endif; ?>

            <p class="mod-note">
                Editing <code>include/config.php</code>. Changes take effect immediately.
                A backup is created automatically in <code>moderator/config-backups/</code> before every save,
                and the 20 most recent backups are kept.
            </p>
            <p class="mod-note">
                Warning: changing <code>SECRET_KEY</code> makes existing encrypted IP log entries unreadable.
            </p>

            <form method="post" action="index.php#config">
                <div class="form-group">
                    <label for="config_content">config.php</label>
                    <textarea id="config_content" name="config_content" class="code-editor"
                              spellcheck="false" required><?= htmlspecialchars($configContent, ENT_QUOTES, 'UTF-8') ?></textarea>
                </div>

                <button type="submit" name="save_config" value="1" class="mod-button"
                        onclick="return confirm('Save changes to include/config.php? A backup will be created first.');">
                    Save Configuration
                </button>
            </form>
        </div>
    </div>

    <script>
        // Clear IP when Thread ID / Timestamp are used, and vice versa.
        const ipInput = document.getElementById('add_ip');
        const threadInput = document.getElementById('add_threadid');
        const timestampInput = document.getElementById('add_timestamp');

        if (threadInput) {
            threadInput.addEventListener('change', function() {
                if (this.value) {
                    ipInput.value = '';
                }
            });
        }

        if (timestampInput) {
            timestampInput.addEventListener('input', function() {
                if (this.value) {
                    ipInput.value = '';
                }
            });
        }

        if (ipInput) {
            ipInput.addEventListener('input', function() {
                if (this.value) {
                    threadInput.value = '';
                    timestampInput.value = '';
                }
            });
        }
    </script>
</body>
</html>

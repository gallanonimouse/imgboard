<?php

class ThreadModel {
    private const THREADS_DIR = __DIR__ . '/../threads';

    public function isValidThreadId($id) {
        // First check the format
        if (preg_match('/^[a-f0-9]{8}$/', $id) !== 1) {
            return false;
        }

        // Next check if the folder and data.json exist
        $threadDir = self::THREADS_DIR . '/' . $id;
        $jsonFile = $threadDir . '/data.json';

        if (!is_dir($threadDir) || !file_exists($jsonFile)) {
            return false;
        }

        // Expiry check is handled separately to keep validation clean
        return true;
    }

    private function generateThreadId() {
        return bin2hex(random_bytes(4)); // 8 hex characters
    }
    
    private function generateImageName() {
        return bin2hex(random_bytes(4)); // 8 hex characters
    }

    private function sanitizeFileName($fileName) {
        return preg_replace('/[^a-zA-Z0-9._-]/', '_', $fileName);
    }

    public function saveUploadedFile($file, $dir, $threadId = null, $timestamp = null, $shouldStamp = false, $password = null) {
        if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
            return null;
        }

        //$safeName = $this->sanitizeFileName($file['name']);
        $safeName = $this->generateImageName().".jpg";
        $targetPath = $dir . '/' . $safeName;

        // Check if it is a JPEG file
        $fileInfo = getimagesize($file['tmp_name']);
        if ($fileInfo === false || $fileInfo[2] !== IMAGETYPE_JPEG) {
            // Return null if not a JPEG
            return null;
        }

        // Get dimensions of the original image
        list($originalWidth, $originalHeight) = $fileInfo;

        // If image scaling is enabled, check height
        if (defined('SHOULD_SCALE_IMAGE') && SHOULD_SCALE_IMAGE && defined('MAX_IMAGE_HEIGHT') && $originalHeight > MAX_IMAGE_HEIGHT) {
            // Calculate new width keeping the aspect ratio
            $newHeight = MAX_IMAGE_HEIGHT;
            $newWidth = intval(($originalWidth / $originalHeight) * $newHeight);

            // Load JPEG image
            $image = imagecreatefromjpeg($file['tmp_name']);

            // Create new scaled image resource
            $newImage = imagecreatetruecolor($newWidth, $newHeight);

            // Perform resampling
            imagecopyresampled($newImage, $image, 0, 0, 0, 0, $newWidth, $newHeight, $originalWidth, $originalHeight);

            // Destroy original image resource
            imagedestroy($image);

            // Apply watermark if stamping is enabled
            if ($shouldStamp && $threadId !== null && $timestamp !== null) {
                $newImage = $this->applyWatermark($newImage, $threadId, $timestamp, $newWidth, $newHeight);
            }

            // Save scaled image
            imagejpeg($newImage, $targetPath, 90); // 90 is JPEG quality

            // Free memory
            imagedestroy($newImage);
        } else {
            // Load and stamp if resizing is not needed
            $image = imagecreatefromjpeg($file['tmp_name']);
            
            // Apply watermark if stamping is enabled
            if ($shouldStamp && $threadId !== null && $timestamp !== null) {
                $image = $this->applyWatermark($image, $threadId, $timestamp, $originalWidth, $originalHeight);
            }
            
            // Save image
            imagejpeg($image, $targetPath, 90);
            
            // Free memory
            imagedestroy($image);
        }

        // Encrypt the image content on disk if password is provided
        if ($password !== null) {
            $contents = file_get_contents($targetPath);
            $encryptedContents = encryptText($contents, $password);
            file_put_contents($targetPath, $encryptedContents);
        }

        return $safeName;
    }

private function applyWatermark($image, $threadId, $timestamp, $width, $height) {
    // Watermark text
    $watermarkText = $threadId . ':' . $timestamp;
    
    // Calculate minimum dimensions for readability
    $minWidthForGrid = 300;   // Single label threshold width
    $minHeightForGrid = 200;  // Single label threshold height
    
    if ($width >= $minWidthForGrid && $height >= $minHeightForGrid) {
        // Large image - apply watermarks in a grid pattern
        $watermarkColor = imagecolorallocate($image, 180, 180, 180); // Light gray
        $spacing_x = max(120, intval($width / 2));   // Larger spacing
        $spacing_y = max(80, intval($height / 6));   // Larger spacing
        
        // Apply watermarks in a checkerboard pattern
        for ($y = 0; $y < $height; $y += $spacing_y) {
            $offset_x = (($y / $spacing_y) % 2 == 0) ? 0 : intval($spacing_x / 2);
            
            for ($x = $offset_x; $x < $width; $x += $spacing_x) {
                imagestring($image, 2, $x, $y, $watermarkText, $watermarkColor);
            }
        }
    } else {
        // Small image - place a single watermark in bottom-left corner
        $watermarkColor = imagecolorallocate($image, 150, 150, 150); // Darker gray for readability
        $textWidth = imagefontwidth(2) * strlen($watermarkText);
        $textHeight = imagefontheight(2);
        
        // Position: bottom-left corner with margin
        $x = 10;
        $y = $height - $textHeight - 10;
        
        // Clamp coordinates to image boundaries
        if ($x < 0) $x = 0;
        if ($y < 0) $y = 0;
        
        imagestring($image, 2, $x, $y, $watermarkText, $watermarkColor);
    }
    
    return $image;
}
    
    public function createThread($threadName, $expiresAt, $message, $imageFile = null, $isPublic = true, $userNick = 'Anonymous', $isStamped = false, $password = null, $freezingMinutes = 0) {
        $threadId = $this->generateThreadId();
        $threadDir = self::THREADS_DIR . '/' . $threadId;
        $time = time();

        if (!is_dir($threadDir)) {
            mkdir($threadDir, 0755, true);
        }

        $image = $this->saveUploadedFile($imageFile, $threadDir, $threadId, $time, $isStamped, $password);

        $data = [
            'thread_name' => $password !== null ? encryptText($threadName, $password) : $threadName,
            'created_at' => time(),
            'expires' => date('Y-m-d H:i:s', strtotime($expiresAt)),
            'is_public' => (bool)$isPublic,
            'is_stamped' => (bool)$isStamped,
            'freezing_minutes' => (int)$freezingMinutes,
            'password_hash' => $password !== null ? password_hash($password, PASSWORD_DEFAULT) : null,
            'messages' => [
                [
                    'message' => $password !== null ? encryptText($message, $password) : $message,
                    'image' => $image,
                    'timestamp' => $time,
                    'nick' => $password !== null ? encryptText($userNick, $password) : $userNick
                ]
            ]
        ];

        file_put_contents($threadDir . '/data.json', json_encode($data, JSON_PRETTY_PRINT));
        
        logThreadAction('c', $threadId, $time);
        
        return $threadId;
    }

    public function addMessageToThread($threadId, $message, $imageFile = null, $userNick = 'Anonymous', $password = null) {
        $jsonFile = self::THREADS_DIR . '/' . $threadId . '/data.json';

        if (!file_exists($jsonFile)) {
            return false;
        }

        $data = json_decode(file_get_contents($jsonFile), true);
        $threadDir = dirname($jsonFile);
        $time = time();

        // Keep timestamps unique so posts added in the same second do not
        // collide in the DOM or get skipped by auto-refresh.
        $lastTimestamp = !empty($data['messages'])
            ? (int)$data['messages'][count($data['messages']) - 1]['timestamp']
            : 0;
        if ($time <= $lastTimestamp) {
            $time = $lastTimestamp + 1;
        }
        
        // Read stamping preference from thread metadata
        $isStamped = $data['is_stamped'] ?? false;
        
        $image = $this->saveUploadedFile($imageFile, $threadDir, $threadId, $time, $isStamped, $password);

        $data['messages'][] = [
            'message' => $password !== null ? encryptText($message, $password) : $message,
            'image' => $image,
            'timestamp' => $time,
            'nick' => $password !== null ? encryptText($userNick, $password) : $userNick
        ];

        file_put_contents($jsonFile, json_encode($data, JSON_PRETTY_PRINT));
        
       logThreadAction('p', $threadId, $time);
        
        // Return the new message metadata so the controller can build links
        // and the AJAX response without reloading the page.
        return [
            'timestamp' => $time,
            'image' => $image,
        ];
    }

    public function getAllThreads() {
        $threads = [];
        $dir = self::THREADS_DIR;

        if (!is_dir($dir)) return $threads;

        foreach (scandir($dir) as $file) {
            if ($file === '.' || $file === '..' || !is_dir("$dir/$file")) continue;
            
            // Check ID format and file existence
            if (!$this->isValidThreadId($file)) continue;

            $jsonFile = "$dir/$file/data.json";
            if (!file_exists($jsonFile)) {
                $this->deleteExpiredThread($file);
                continue;
            }

            $data = json_decode(file_get_contents($jsonFile), true);
            if ($data === null) {
                $this->deleteExpiredThread($file);
                continue;
            }

            // Expiry validation
            if (!$this->isThreadActive($data['expires'])) {
                $this->deleteExpiredThread($file);
                continue;
            }

            if (isset($data['is_public']) && $data['is_public']) {
                $lastActivity = !empty($data['messages']) 
                    ? end($data['messages'])['timestamp'] 
                    : $data['created_at'];
                
                $threads[] = [
                    'id' => $file, 
                    'data' => $data,
                    'last_activity' => $lastActivity
                ];
            }
        }

        usort($threads, function($a, $b) {
            return $b['last_activity'] - $a['last_activity'];
        });

        return $threads;
    }

    public function getThreadById($threadId) {
        $jsonFile = self::THREADS_DIR . '/' . $threadId . '/data.json';

        if (!file_exists($jsonFile)) {
            return null;
        }

        $data = json_decode(file_get_contents($jsonFile), true);
        if ($this->isThreadActive($data['expires'])) {
            return ['id' => $threadId, 'data' => $data];
        } else {
            $this->deleteExpiredThread($threadId);
            return null;
        }
    }

    private function isThreadActive($expires) {
        return strtotime($expires) > time();
    }

    private function deleteExpiredThread($threadId) {
        $dir = self::THREADS_DIR . '/' . $threadId;
        if (!is_dir($dir)) return;

        // Cleanly remove files
        foreach (scandir($dir) as $file) {
            if ($file !== '.' && $file !== '..') {
                $filePath = "$dir/$file";
                if (is_file($filePath)) {
                    @unlink($filePath); // Suppress errors
                }
            }
        }
        @rmdir($dir); // Suppress errors
    }
}

<?php
session_start();
// Hi Officer! 
// Bad guys' IPs and reasons can be found in boardban.json and ipnotes.json

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'include/config.php';
require_once 'include/functions.php';

/////////////////


$ip = getRealIP();
$banFile = __DIR__ . '/boardban.json';


if (file_exists($banFile)) {
    $banned = json_decode(file_get_contents($banFile), true);
    if (is_array($banned)) 
    {
        foreach ($banned as $entry) {
            if (isset($entry['ip']) && $entry['ip'] === $ip) {
                http_response_code(403);
                die('BANNED');
            }
        }
    }
}

////////////////




// Check if terms of service are accepted
$termsAccepted = isset($_COOKIE['terms_accepted']) && $_COOKIE['terms_accepted'] === '1';

if (!$termsAccepted) {
    // If the terms acceptance form was submitted
    if (isset($_POST['accept_terms']) && $_POST['accept_terms']) {
        // Set acceptance cookie
        setcookie('terms_accepted', '1', time() + (86400 * 365), "/"); // valid for 1 year
        
        // Retrieve or set nickname
        if (!isset($_COOKIE['user_nick'])) {
            $random_nick = $nicks[array_rand($nicks)];
            setcookie('user_nick', $random_nick, time() + (86400 * 30), "/");
            $_COOKIE['user_nick'] = $random_nick;
        }
        
        // Redirect to the requested URL or the homepage
        $redirect = $_POST['redirect'] ?? '';
        $redirectPassword = $_POST['redirect_password'] ?? '';
        if (!empty($redirect)) {
            $url = "index.php?thread=" . urlencode($redirect);
            if (!empty($redirectPassword)) {
                $url .= "&password=" . urlencode($redirectPassword);
            }
            header("Location: " . $url);
        } else {
            header("Location: index.php");
        }
        exit();
    }
    
    // Display the terms of service page
    $redirectUrl = $_SERVER['REQUEST_URI']; // Save original URL
    require 'view/terms.php';
    exit();
}

// Set random nickname in cookie if it doesn't exist (for older users without nickname)
if (!isset($_COOKIE['user_nick'])) {
    $random_nick = $nicks[array_rand($nicks)];
    setcookie('user_nick', $random_nick, time() + (86400 * 30), "/");
    $_COOKIE['user_nick'] = $random_nick;
}

// Load ThreadModel class definition
require_once __DIR__ . '/model/ThreadModel.php';

// Set default query parameters
$operation = isset($_GET['op']) ? $_GET['op'] : null; // e.g., 'newthread', 'addpost'
$thread = isset($_GET['thread']) ? $_GET['thread'] : null; // e.g., '2cfed' (thread ID)
//if (!empty($_POST['redirect'])) $thread = $_POST['redirect'];

if ($operation === 'newthread') {
    // Create new thread
    require 'controller/ThreadController.php';
    $controller = new ThreadController();
    $controller->createThread();
} elseif ($operation === 'addpost' && $thread !== null) {
    // Add post to existing thread
    require 'controller/ThreadController.php';
    $controller = new ThreadController();
    $controller->addPost($thread);
} elseif ($operation === 'getthreadjson' && $thread !== null) {
    // Fetch decrypted thread JSON
    require 'controller/ThreadController.php';
    $controller = new ThreadController();
    $controller->getThreadJson($thread);
} elseif ($operation === 'freezing' && $thread !== null) {
    require 'controller/ThreadController.php';
    $controller = new ThreadController();
    $controller->freezingPage($thread);
} elseif ($operation === 'viewimage' && $thread !== null && isset($_GET['image'])) {
    // Fetch decrypted image
    require 'controller/ThreadController.php';
    $controller = new ThreadController();
    $controller->viewImage($thread, $_GET['image']);
} elseif ($thread !== null) {
    // Display thread with the specified ID
    require 'controller/ThreadController.php';
    $controller = new ThreadController();
    $controller->viewThread($thread);
} else {
    // Homepage - list all threads
    require 'controller/ThreadController.php';
    $controller = new ThreadController();
    $controller->listThreads();
}

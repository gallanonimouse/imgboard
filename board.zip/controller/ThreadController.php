<?php

class ThreadController {
    private $model;

    public function __construct() {
        $this->model = new ThreadModel();
    }
    
    private function sanitizeMessage($message) {
        if (!is_string($message)) {
            return '';
        }

        // Remove control characters (0x00-0x08, 0x0B, 0x0C, 0x0E-0x1F, 0x7F), keeping \n, \r, \t
        $message = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $message);

        // Ensure UTF-8 encoding
        if (!mb_check_encoding($message, 'UTF-8')) {
            $message = mb_convert_encoding($message, 'UTF-8', 'UTF-8');
        }

        // Optional: limit length (e.g., to 10,000 characters)
        $message = mb_substr($message, 0, 10000);

        // Remove leading/trailing whitespace
        return trim($message);
    }

    private function isAjaxRequest() {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH'])
            && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }

    private function abortRequest($status, $message) {
        http_response_code($status);

        if ($this->isAjaxRequest()) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'success' => false,
                'error' => $message,
            ]);
        } else {
            echo htmlspecialchars($message);
        }

        exit();
    }

    public function listThreads() {
        $threads = $this->model->getAllThreads();
        require __DIR__ . '/../view/threadIndex.php';
    }

    public function viewThread($threadId) {
        if (!$this->model->isValidThreadId($threadId)) {
            http_response_code(400);
            require __DIR__ . '/../view/invalidThread.php';
            return;
        }
        $thread = $this->model->getThreadById($threadId);
        if (!empty($thread)){
            $password_error = false;
            
            // If the thread is password protected
            if (!empty($thread['data']['password_hash'])) {
                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                
                // If the user submitted a password via POST form
                if (isset($_POST['thread_password'])) {
                    if (password_verify($_POST['thread_password'], $thread['data']['password_hash'])) {
                        $_SESSION['thread_passwords'][$threadId] = $_POST['thread_password'];
                    } else {
                        $password_error = true;
                    }
                }

                // If password provided via GET parameter (direct link access: ?thread=ID&password=test)
                if (isset($_GET['password']) && !empty($_GET['password'])) {
                    if (password_verify($_GET['password'], $thread['data']['password_hash'])) {
                        $_SESSION['thread_passwords'][$threadId] = $_GET['password'];
                    } else {
                        $password_error = true;
                    }
                }
                
                $stored_password = $_SESSION['thread_passwords'][$threadId] ?? null;
                if ($stored_password === null || !password_verify($stored_password, $thread['data']['password_hash'])) {
                    require __DIR__ . '/../view/threadPassword.php';
                    return;
                }
                
                // Decrypt thread content
                try {
                    $thread['data']['thread_name'] = decryptText($thread['data']['thread_name'], $stored_password);
                    foreach ($thread['data']['messages'] as &$msg) {
                        $msg['message'] = decryptText($msg['message'], $stored_password);
                        $msg['nick'] = decryptText($msg['nick'], $stored_password);
                    }
                    unset($msg);
                } catch (Exception $e) {
                    unset($_SESSION['thread_passwords'][$threadId]);
                    $password_error = true;
                    require __DIR__ . '/../view/threadPassword.php';
                    return;
                }
            }
            
            // Share password for copy-link button (only if thread is password protected)
            $thread['_share_password'] = !empty($thread['data']['password_hash'])
                ? ($_SESSION['thread_passwords'][$threadId] ?? null)
                : null;

            require __DIR__ . '/../view/threadView.php';
        }
        else {
            http_response_code(400);
            require __DIR__ . '/../view/invalidThread.php';
            return;
        }
    }

    public function createThread() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $threadName = trim($_POST['thread_name']);
            $expiresAtOption = $_POST['expires_at'];
            $message = $this->sanitizeMessage($_POST['message']);
            $imageFile = $_FILES['image'] ?? null;
            $isPublic = isset($_POST['is_public']) && $_POST['is_public'] == '1';
            $isStamped = isset($_POST['is_stamped']) && $_POST['is_stamped'] == '1';
            $isFreezing = isset($_POST['is_freezing']) && $_POST['is_freezing'] == '1';
            $freezingMinutes = $isFreezing ? (int)($_POST['freezing_minutes'] ?? 5) : 0;
            $userNick = $_COOKIE['user_nick'] ?? 'Anonymous';

            if (empty($threadName)) {
                die("Thread name is required.");
            }
            if (empty($message)) {
                die("Message cannot be empty.");
            }

            $password = null;
            if (!$isPublic && !empty($_POST['thread_password'])) {
                $password = $_POST['thread_password'];
            }

            $expiresAt = $this->calculateExpiryDate($expiresAtOption);
            $threadId = $this->model->createThread($threadName, $expiresAt, $message, $imageFile, $isPublic, $userNick, $isStamped, $password, $freezingMinutes);
            
            if ($password !== null) {
                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                $_SESSION['thread_passwords'][$threadId] = $password;
            }

            header("Location: index.php?thread=" . urlencode($threadId));
            exit();
        }

        require __DIR__ . '/../view/threadNew.php';
    }

    // Calculate expiry date based on selection
    private function calculateExpiryDate($expiresAtOption) {
        $currentDate = new DateTime();  // Get current date and time

        switch ($expiresAtOption) {
            case '15min':
                $currentDate->add(new DateInterval('PT15M')); // Add 15 minutes
                break;
            case '1h':
                $currentDate->add(new DateInterval('PT1H')); // Add 1 hour
                break;
            case '3h':
                $currentDate->add(new DateInterval('PT3H')); // Add 3 hours
                break;
            case '6h':
                $currentDate->add(new DateInterval('PT6H')); // Add 6 hours
                break;
            case '1d':
                $currentDate->add(new DateInterval('P1D')); // Add 1 day
                break;
            case '2d':
                $currentDate->add(new DateInterval('P2D')); // Add 2 days
                break;
            case '7d':
                $currentDate->add(new DateInterval('P7D')); // Add 7 days
                break;          
        }

        // Return date in Y-m-d H:i:s format
        return $currentDate->format('Y-m-d H:i:s');
    }

    public function addPost($threadId) {
        if (!$this->model->isValidThreadId($threadId)) {
            $this->abortRequest(400, 'Invalid thread ID.');
        }

        $thread = $this->model->getThreadById($threadId);
        if (empty($thread)) {
            $this->abortRequest(400, 'Invalid thread ID.');
        }

        $password = null;
        if (!empty($thread['data']['password_hash'])) {
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            $password = $_SESSION['thread_passwords'][$threadId] ?? null;
            if ($password === null || !password_verify($password, $thread['data']['password_hash'])) {
                $this->abortRequest(403, 'Forbidden: Password required.');
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $message = $this->sanitizeMessage($_POST['message'] ?? '');
            $imageFile = $_FILES['image'] ?? null;
            $userNick = $_COOKIE['user_nick'] ?? 'Anonymous';

            $newMessage = $this->model->addMessageToThread($threadId, $message, $imageFile, $userNick, $password);
            if ($newMessage === false) {
                $this->abortRequest(500, 'Could not add the post. Please try again.');
            }

            // AJAX submission: return the new post instead of redirecting/reloading
            if ($this->isAjaxRequest()) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode([
                    'success' => true,
                    'thread_id' => $threadId,
                    // The client uses this to choose between the public image path
                    // and the session-protected viewimage endpoint.
                    'password_hash' => !empty($thread['data']['password_hash']),
                    'message' => [
                        'timestamp' => $newMessage['timestamp'],
                        'message' => $message,
                        'nick' => $userNick,
                        'image' => $newMessage['image'],
                    ],
                ]);
                exit();
            }

            $redirect = "index.php?thread=" . urlencode($threadId);
            if (!empty($newMessage['timestamp'])) {
                // Jump straight to the newly added post
                $redirect .= '#p' . $newMessage['timestamp'];
            }
            header("Location: " . $redirect);
            exit();
        }

        $this->viewThread($threadId);
    }

    public function getThreadJson($threadId) {
        if (!$this->model->isValidThreadId($threadId)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid thread ID.']);
            return;
        }

        $thread = $this->model->getThreadById($threadId);
        if (empty($thread)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid thread ID.']);
            return;
        }

        if (!empty($thread['data']['password_hash'])) {
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            $password = $_SESSION['thread_passwords'][$threadId] ?? null;
            if ($password === null || !password_verify($password, $thread['data']['password_hash'])) {
                http_response_code(403);
                echo json_encode(['error' => 'Forbidden: Password required.']);
                return;
            }

            // Decrypt thread text data for the JSON output
            try {
                $thread['data']['thread_name'] = decryptText($thread['data']['thread_name'], $password);
                foreach ($thread['data']['messages'] as &$msg) {
                    $msg['message'] = decryptText($msg['message'], $password);
                    $msg['nick'] = decryptText($msg['nick'], $password);
                }
                unset($msg);
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['error' => 'Decryption failed.']);
                return;
            }
        }

        header('Content-Type: application/json');
        echo json_encode($thread['data']);
        exit();
    }

    public function freezingPage($threadId) {
        require __DIR__ . '/../view/freezing.php';
    }

    public function viewImage($threadId, $imageName) {
        if (!$this->model->isValidThreadId($threadId)) {
            http_response_code(400);
            require __DIR__ . '/../view/invalidThread.php';
            exit();
        }

        $thread = $this->model->getThreadById($threadId);
        if (empty($thread)) {
            http_response_code(400);
            require __DIR__ . '/../view/invalidThread.php';
            exit();
        }

        $filePath = __DIR__ . '/../threads/' . $threadId . '/' . basename($imageName);
        if (!file_exists($filePath)) {
            http_response_code(404);
            echo "Image not found.";
            return;
        }

        if (!empty($thread['data']['password_hash'])) {
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            $password = $_SESSION['thread_passwords'][$threadId] ?? null;
            if ($password === null || !password_verify($password, $thread['data']['password_hash'])) {
                http_response_code(403);
                echo "Forbidden: Password required.";
                return;
            }

            // Decrypt image content and stream it
            try {
                $contents = file_get_contents($filePath);
                $decrypted = decryptText($contents, $password);
                header('Content-Type: image/jpeg');
                echo $decrypted;
                exit();
            } catch (Exception $e) {
                http_response_code(500);
                echo "Decryption failed.";
                return;
            }
        } else {
            // Serve image directly
            header('Content-Type: image/jpeg');
            readfile($filePath);
            exit();
        }
    }
}

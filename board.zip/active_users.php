<?php
// active_users.php - manages active users in a thread folder

header('Content-Type: application/json');

// Get request data
$input = json_decode(file_get_contents('php://input'), true);
$threadId = $input['thread_id'] ?? null;
$userId = $input['user_id'] ?? null;
$action = $input['action'] ?? 'heartbeat';

if (!$threadId || !$userId) {
    http_response_code(400);
    exit;
}

// Validate thread ID (safe format check)
if (!preg_match('/^[a-f0-9]{8}$/', $threadId)) {
    http_response_code(400);
    exit;
}

// Path to thread folder
$threadDir = __DIR__ . '/threads/' . $threadId;
$activeFile = $threadDir . '/active_users.json';

// Check if thread directory exists
if (!is_dir($threadDir)) {
    http_response_code(404);
    exit;
}

// Load existing active users
$users = [];
if (file_exists($activeFile)) {
    $users = json_decode(file_get_contents($activeFile), true) ?: [];
    // Remove expired users (inactive for more than 45 seconds)
    $currentTime = time();
    $users = array_filter($users, function($user) use ($currentTime) {
        return ($currentTime - $user['last_seen']) < 45;
    });
    
    // Convert back to associative array
    $usersAssoc = [];
    foreach ($users as $user) {
        $usersAssoc[$user['user_id']] = $user;
    }
    $users = $usersAssoc;
}

// Handle action
if ($action === 'leave') {
    // Remove user
    unset($users[$userId]);
} else {
    // Update/add user (overwrites existing user with the same user_id)
    $users[$userId] = [
        'last_seen' => time(),
        'user_id' => $userId
    ];
}

// Save data (or delete empty file)
if (!empty($users)) {
    // Convert to indexed array for saving
    $usersToSave = array_values($users);
    file_put_contents($activeFile, json_encode($usersToSave));
} else {
    if (file_exists($activeFile)) {
        unlink($activeFile);
    }
}

// Return the count of active users
echo json_encode(['active_users' => count($users)]);

<?php

/*/////////////////////////////////////////////////////
    ZIP update script
/////////////////////////////////////////////////////*/

require_once 'include/config.php';

$PASSWORD         = SECRET_KEY; // From config.php
$BASE_DIR         = __DIR__;
$SELF_FILE        = basename(__FILE__);
$SKIP_DIRS        = ['threads', 'include']; // Directories preserved during cleanup (include/config.php is kept and merged; moderator is overwritten from ZIP)
$SKIP_ON_EXTRACT  = ['threads', '.git', '__MACOSX']; // Root entries NOT extracted from ZIP
$REQUIRED_ENTRIES = ['index.php', 'style.css']; // Guards against a package without the site stylesheet

// Data files that must survive an update even if they are stored in the board root
$PROTECTED_FILES = ['boardban.json'];
$notesRelative = defined('IP_NOTES_FILE')
    ? ltrim(str_replace('\\', '/', trim((string)IP_NOTES_FILE)), '/')
    : '';
if ($notesRelative !== '' && !preg_match('/^[A-Za-z]:/', $notesRelative)) {
    $PROTECTED_FILES[] = $notesRelative;
}

$PROTECTED_ROOTS = [];
foreach ($PROTECTED_FILES as $protectedFile) {
    $root = explode('/', ltrim($protectedFile, '/'))[0] ?? '';
    if ($root !== '') {
        $PROTECTED_ROOTS[] = $root;
    }
}

// Config file that must not be deleted or overwritten.
// New parameters from the package are appended; existing parameters are left unchanged.
$CONFIG_MERGE_FILE = 'include/config.php';

$updateResult   = null;
$extractedCount = 0;

/* ---------- Helpers ---------- */

function deleteRecursive($path, $baseDir, $selfFile, $skipDirs) {
    if (is_dir($path)) {
        if (in_array(basename($path), $skipDirs, true)) {
            return;
        }
        foreach (scandir($path) as $item) {
            if ($item === '.' || $item === '..') continue;
            deleteRecursive($path . '/' . $item, $baseDir, $selfFile, $skipDirs);
        }
        if ($path !== $baseDir) {
            @rmdir($path);
        }
    } else {
        if (basename($path) === $selfFile) return;
        @unlink($path);
    }
}

function normalizeZipEntry($filename) {
    $filename = str_replace('\\', '/', $filename);
    $filename = rtrim($filename, '/');

    // Remove leading "./" segments used by some archive tools
    while (substr($filename, 0, 2) === './') {
        $filename = substr($filename, 2);
    }

    return $filename;
}

function isSafeZipEntry($entry) {
    if ($entry === '' || $entry[0] === '/') {
        return false;
    }

    // Reject absolute Windows paths (e.g. C:\...)
    if (preg_match('/^[A-Za-z]:/', $entry)) {
        return false;
    }

    // Reject directory traversal
    return !in_array('..', explode('/', $entry), true);
}

function describeUploadError($code) {
    $messages = [
        UPLOAD_ERR_INI_SIZE   => 'The uploaded archive is larger than the server allows (upload_max_filesize).',
        UPLOAD_ERR_FORM_SIZE  => 'The uploaded archive is larger than the form allows.',
        UPLOAD_ERR_PARTIAL    => 'The archive was only partially uploaded. Please try again.',
        UPLOAD_ERR_NO_FILE    => 'No ZIP file was uploaded.',
        UPLOAD_ERR_NO_TMP_DIR => 'The server is missing a temporary upload directory.',
        UPLOAD_ERR_CANT_WRITE => 'The server could not write the uploaded archive to disk.',
        UPLOAD_ERR_EXTENSION  => 'A server extension stopped the upload.',
    ];

    return $messages[$code] ?? 'Unknown upload error.';
}

function extractDefinedParams($phpContents) {
    $params = [];
    if (preg_match_all("/define\(\s*['\"]([^'\"]+)['\"]\s*,\s*(.+?)\s*\);/", $phpContents, $m, PREG_SET_ORDER)) {
        foreach ($m as $match) {
            $params[$match[1]] = $match[0];
        }
    }
    return $params;
}

function mergeConfigFile($existingPath, $newContents) {
    $existingContents = @file_get_contents($existingPath);
    if ($existingContents === false) {
        return $newContents;
    }

    $oldParams = extractDefinedParams($existingContents);
    $newParams = extractDefinedParams($newContents);

    $toAppend = [];
    foreach ($newParams as $name => $defineStmt) {
        if (!array_key_exists($name, $oldParams)) {
            $toAppend[] = $defineStmt;
        }
    }

    if (empty($toAppend)) {
        return $existingContents;
    }

    $append = "\n// --- New config parameters added by updater ---\n" . implode("\n", $toAppend) . "\n";

    if (preg_match('/\?>\s*$/', $existingContents)) {
        return preg_replace('/\?>\s*$/', $append . "?>\n", $existingContents);
    }

    return rtrim($existingContents, "\r\n") . $append;
}

function fixPermissions($dir, $dirMode = 0755, $fileMode = 0644) {
    if (!is_dir($dir)) {
        return;
    }
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iterator as $item) {
        $path = $item->getPathname();
        try {
            if ($item->isDir()) {
                @chmod($path, $dirMode);
            } else {
                @chmod($path, $fileMode);
            }
        } catch (Throwable $e) {
            // Permission changes may be restricted on some hosting; ignore failures.
        }
    }
}

/* ---------- Main logic ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $zip = null;

    try {
        if (!isset($_POST['password']) || !is_string($_POST['password'])) {
            throw new RuntimeException('Admin password is required.');
        }

        if (!hash_equals((string)$PASSWORD, $_POST['password'])) {
            throw new RuntimeException('Invalid password.');
        }

        if (!isset($_FILES['zipFile']) || !is_array($_FILES['zipFile'])) {
            throw new RuntimeException('No ZIP file was uploaded.');
        }

        $uploadError = $_FILES['zipFile']['error'] ?? UPLOAD_ERR_NO_FILE;
        if ($uploadError !== UPLOAD_ERR_OK) {
            throw new RuntimeException(describeUploadError($uploadError));
        }

        $zipTmp = $_FILES['zipFile']['tmp_name'] ?? '';
        if ($zipTmp === '' || !is_uploaded_file($zipTmp)) {
            throw new RuntimeException('The uploaded file could not be verified.');
        }

        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('The ZIP extension is not available on this server.');
        }

        $zip = new ZipArchive();
        $openResult = $zip->open($zipTmp);
        if ($openResult !== true) {
            throw new RuntimeException('Could not open the ZIP archive' . (is_int($openResult) ? " (error code: {$openResult})" : '') . '.');
        }

        // --- 1. Validate the archive before touching any existing files ---
        $entries = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);
            if ($filename === false) {
                throw new RuntimeException('Could not read one of the archive entries.');
            }

            $entry = normalizeZipEntry($filename);
            if ($entry === '') continue;

            if (!isSafeZipEntry($entry)) {
                throw new RuntimeException("The archive contains an unsafe path: {$entry}");
            }

            $entries[] = $entry;
        }

        $missingEntries = array_diff($REQUIRED_ENTRIES, $entries);
        if (!empty($missingEntries)) {
            throw new RuntimeException(
                'The archive is missing required file(s): ' . implode(', ', $missingEntries) .
                '. Upload a complete site package so the stylesheet stays connected.'
            );
        }

        // --- 2. Clean current directory (with exclusions) ---
        foreach (scandir($BASE_DIR) as $item) {
            if ($item === '.' || $item === '..' || $item === $SELF_FILE
                || in_array($item, $SKIP_DIRS, true)
                || in_array($item, $PROTECTED_ROOTS, true)) {
                continue;
            }
            deleteRecursive($BASE_DIR . '/' . $item, $BASE_DIR, $SELF_FILE, $SKIP_DIRS);
        }

        // --- 3. Extract ZIP, skipping protected root entries ---
        // Pass A: create all directories first so parent dirs exist before files are written.
        $dirsToCreate = [];
        $newConfigContents = null;
        $newUpdaterContents = null;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);
            if ($filename === false) continue;

            $entry = normalizeZipEntry($filename);
            if ($entry === '') continue;

            if ($entry === $CONFIG_MERGE_FILE) {
                continue; // handled separately below
            }

            $parts    = explode('/', $entry);
            $rootName = $parts[0] ?? '';

            if (in_array($rootName, $SKIP_ON_EXTRACT, true) || in_array($rootName, $PROTECTED_ROOTS, true)) {
                continue;
            }

            // Directory entry in ZIP
            if (substr($filename, -1) === '/' || substr($filename, -1) === '\\') {
                $dirsToCreate[] = $entry;
                continue;
            }

            // Parent directory of a file entry
            $parentDir = dirname($entry);
            if ($parentDir !== '.' && $parentDir !== '') {
                $dirsToCreate[] = $parentDir;
            }
        }

        // Create collected directories (unique, in order)
        $dirsToCreate = array_unique($dirsToCreate);
        foreach ($dirsToCreate as $dirEntry) {
            $destDir = $BASE_DIR . '/' . $dirEntry;
            if (!is_dir($destDir) && !@mkdir($destDir, 0775, true)) {
                throw new RuntimeException("Could not create directory: {$dirEntry}");
            }
            @chmod($destDir, 0775);
        }

        // Pass B: extract files
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);
            if ($filename === false) continue;

            $entry = normalizeZipEntry($filename);
            if ($entry === '') continue;

            // Preserve include/config.php: read its contents but do not overwrite it.
            // It is merged separately so new parameters are appended and existing ones stay unchanged.
            if ($entry === $CONFIG_MERGE_FILE) {
                $newConfigContents = $zip->getFromIndex($i);
                continue;
            }

            // Defer self-update: do not overwrite updater.php while it is running.
            // It will be atomically replaced via rename() at the end of the update.
            if ($entry === $SELF_FILE) {
                $newUpdaterContents = $zip->getFromIndex($i);
                continue;
            }

            $parts    = explode('/', $entry);
            $rootName = $parts[0] ?? '';

            if (in_array($rootName, $SKIP_ON_EXTRACT, true) || in_array($rootName, $PROTECTED_ROOTS, true)) {
                continue;
            }

            // Skip directory entries (already created in Pass A)
            if (substr($filename, -1) === '/' || substr($filename, -1) === '\\') {
                continue;
            }

            $dest = $BASE_DIR . '/' . $entry;

            $contents = $zip->getFromIndex($i);
            if ($contents === false) {
                throw new RuntimeException("Could not read file from archive: {$entry}");
            }

            $fullPath = $BASE_DIR . '/' . $entry;
            if (@file_put_contents($fullPath, $contents) === false) {
                throw new RuntimeException("Could not write file: {$fullPath}");
            }

            @chmod($fullPath, 0644);
            $extractedCount++;
        }

        // Merge config.php: append new parameters, keep existing ones unchanged
        if ($newConfigContents !== null) {
            $configPath = $BASE_DIR . '/' . $CONFIG_MERGE_FILE;
            if (is_file($configPath)) {
                $merged = mergeConfigFile($configPath, $newConfigContents);
                if (@file_put_contents($configPath, $merged) === false) {
                    throw new RuntimeException('Could not write merged config file: ' . $CONFIG_MERGE_FILE);
                }
            } elseif ($newConfigContents !== false) {
                $dir = dirname($configPath);
                if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
                    throw new RuntimeException('Could not create directory: ' . dirname($CONFIG_MERGE_FILE));
                }
                if (@file_put_contents($configPath, $newConfigContents) === false) {
                    throw new RuntimeException('Could not write config file: ' . $CONFIG_MERGE_FILE);
                }
            }
        }

        // --- Set filesystem permissions so Apache and the update script can read/write ---
        // Directories: 0755 (owner can write/traverse, others can read)
        // Files:       0644 (owner can read/write, others can read)
        fixPermissions($BASE_DIR, 0755, 0644);

        // Data folders the script itself must be able to write to (new threads, moderator actions, config merge)
        foreach (['threads', 'moderator', 'include'] as $writableDir) {
            $wd = $BASE_DIR . '/' . $writableDir;
            if (is_dir($wd)) {
                @chmod($wd, 0775);
            }
        }

        // Atomically replace updater.php with the new version from the ZIP.
        // We write to a temporary file first, then rename() over the running script.
        // On Linux this is safe: the currently executing PHP process keeps using the old inode,
        // and the new file will be served on the next request.
        if ($newUpdaterContents !== null) {
            $tmpUpdater = $BASE_DIR . '/' . $SELF_FILE . '.tmp.' . uniqid('', true);
            if (@file_put_contents($tmpUpdater, $newUpdaterContents) === false) {
                throw new RuntimeException('Could not write temporary updater file.');
            }
            @chmod($tmpUpdater, 0644);
            if (!@rename($tmpUpdater, $BASE_DIR . '/' . $SELF_FILE)) {
                @unlink($tmpUpdater);
                throw new RuntimeException('Could not replace ' . $SELF_FILE . ' with the new version.');
            }
        }

        // Make sure PHP serves the freshly extracted files
        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }

        $updateResult = [
            'type'    => 'success',
            'message' => 'The update package was uploaded and extracted successfully.',
            'details' => $extractedCount . ' file(s) extracted. Existing threads were left untouched.',
        ];
    } catch (Throwable $e) {
        $updateResult = [
            'type'    => 'error',
            'message' => $e->getMessage(),
        ];
    } finally {
        if ($zip instanceof ZipArchive) {
            $zip->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Board - Imageboard</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); ?>">
</head>
<body>
    <div class="container">
        <h1>Board Updater</h1>

        <?php if ($updateResult !== null): ?>
            <div class="updater-alert <?php echo htmlspecialchars($updateResult['type']); ?>" role="status" aria-live="polite">
                <strong><?php echo $updateResult['type'] === 'success' ? 'Update completed' : 'Update failed'; ?></strong>
                <p><?php echo htmlspecialchars($updateResult['message']); ?></p>
                <?php if (!empty($updateResult['details'])): ?>
                    <p><?php echo htmlspecialchars($updateResult['details']); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="updater-note">
            <strong>Before you upload</strong>
            <ul>
                <li>Upload a complete ZIP package containing <code>index.php</code> and <code>style.css</code>.</li>
                <li>All existing site files are replaced, except <code>threads/</code>, <code>boardban.json</code> and the IP notes file, which are preserved. The <code>moderator/</code> folder is overwritten from the ZIP package.</li>
                <li>The stylesheet is validated first, so a broken package will not leave the board without CSS.</li>
                <li>This action cannot be undone.</li>
            </ul>
        </div>

        <form method="post" enctype="multipart/form-data" class="create-thread-form" onsubmit="return confirm('Replace all site files with the uploaded package? Threads will be preserved. The moderator folder will be overwritten.');">
            <div class="form-group">
                <label for="password">Admin password:</label>
                <input type="password" id="password" name="password" autocomplete="current-password" placeholder="Password" required>
            </div>

            <div class="form-group">
                <label for="zipFile">Update package (.zip):</label>
                <input type="file" id="zipFile" name="zipFile" accept=".zip,application/zip" required>
            </div>

            <button type="submit">Upload and Extract</button>
        </form>

        <a href="index.php" class="btn">Back to Board</a>
    </div>
</body>
</html>

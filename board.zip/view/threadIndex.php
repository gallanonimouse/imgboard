<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imageboard</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
</head>
<body>
    <div class="container">
            <h1>Imageboard - All Threads</h1>
            <a href="index.php?op=newthread" class="btn">Create New Thread</a>
            <form method="GET" action="index.php" class="add-post-form">
                <div class="form-group">
                    <label for="thread">Thread id:</label>
                    <input type="text" name="thread" id="thread" required>
                </div>
                    <button type="submit">SHOW!</button>
                
            </form>
            <div class="threads-list">
                <?php if (empty($threads)): ?>
                    <p>No active threads found.</p>
                <?php else: ?>
                    <?php foreach ($threads as $threadItem): ?>
                        <div class="thread-item">
                        
                            <a href="index.php?thread=<?php echo htmlspecialchars($threadItem['id']); ?>" 
                               class="thread-link" 
                               aria-label="View thread: <?php echo htmlspecialchars($threadItem['data']['thread_name']); ?>">
                            </a>
                        
                            <h3><?php echo htmlspecialchars($threadItem['data']['thread_name']); ?></h3>
                            
                            <!-- Thread stats -->
                            <div class="thread-stats">
                                <?php 
                                $messageCount = count($threadItem['data']['messages']);
                                $expires_timestamp = strtotime($threadItem['data']['expires']);
                                $remaining_seconds = $expires_timestamp - time();
                                ?>
                                <span class="post-count"><?php echo $messageCount; ?> post<?php echo $messageCount !== 1 ? 's' : ''; ?></span>
                                
                                <?php if ($remaining_seconds > 0): ?>
                                    <span class="expiration-timer"><?php echo formatTimeRemaining($remaining_seconds); ?></span>
                                <?php else: ?>
                                    <span class="expired">Expired</span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if (!empty($threadItem['data']['messages'])): ?>
                                <?php 
                                $firstMessage = $threadItem['data']['messages'][0];
                                $lastMessage = end($threadItem['data']['messages']);
                                ?>
                                
                                <!-- First message preview -->
                                <div class="preview-section first-preview">
                                    <div class="preview-header">
                                        <span class="preview-label">Initial Post:</span>
                                        <span class="preview-nick"><?php echo htmlspecialchars($firstMessage['nick']); ?></span>
                                    </div>
                                    
                                    <?php if (!empty($firstMessage['image'])): ?>
                                        <div class="preview-image">
                                            <img src="threads/<?php echo htmlspecialchars($threadItem['id']); ?>/<?php echo htmlspecialchars($firstMessage['image']); ?>" 
                                                 alt="Preview image" 
                                                 onerror="this.style.display='none'">
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="preview-message">
                                        <?php echo htmlspecialchars(substr($firstMessage['message'], 0, 100)); ?>
                                        <?php if (strlen($firstMessage['message']) > 100): ?>...<?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>  
    </div>
</body>
</html>

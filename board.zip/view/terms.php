<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms of Service - Imageboard</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
</head>
<body>
    <div class="container">
        <h1>Terms of Service</h1>
        
        <div class="terms-content">
                <h2>1. General Rules</h2>
                <p>By using this imageboard, you agree to follow basic community guidelines.</p>

                <h2>2. Content Policy</h2>
                <p>You are responsible for all content you post. Do not upload illegal, harmful, or prohibited content.</p>

                <h2>3. Adult Content Warning</h2>
                <p>This imageboard may contain content intended for adults only. By continuing to use the service, you confirm that you are legally allowed to view such content in your country.</p>

                <h2>4. Privacy and Cookies</h2>
                <p>This service uses cookies for basic functionality, including nickname assignment and session management. By using the site, you consent to the use of cookies. No personal data is intentionally collected.</p>

                <h2>5. Data Retention</h2>
                <p>All threads and posts are automatically deleted after their expiration time. No permanent storage of user data is guaranteed.</p>

                <h2>6. Legal Compliance</h2>
                <p>You agree to comply with all applicable local, national, and international laws while using this service.</p>

                <h2>7. No Warranty</h2>
                <p>This service is provided "as is" without any warranties. Use at your own risk.</p>
        </div>
        
        <form method="POST" action="index.php?accept_terms=1" class="terms-form">
            <input type="hidden" name="redirect" value="<?= !empty($_GET['thread'])?$_GET['thread']:'' ?>">
            <input type="hidden" name="redirect_password" value="<?= !empty($_GET['password'])?$_GET['password']:'' ?>">
            <div class="form-group">
                <label>
                    <input type="checkbox" name="accept_terms" required> 
                    I have read and agree to the Terms of Service
                </label>
            </div>
            <button type="submit" class="btn">Accept and Continue</button>
        </form>
    </div>
</body>
</html> 

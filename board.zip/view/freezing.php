<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thread Frozen - Imageboard</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
</head>
<body>
    <div class="container">
        <div class="freezing-page">
            <h1>Thread Frozen</h1>

            <div class="freezing-icon">&#10052;</div>

            <div class="freezing-message">
                <p>You have been inactive for too long.</p>
                <p>This thread requires active participation.</p>
                <p>Please return to the thread and send a message to continue.</p>
            </div>

            <?php if (isset($threadId)): ?>
                <a href="index.php?thread=<?php echo htmlspecialchars($threadId); ?>" class="btn">Return to Thread</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

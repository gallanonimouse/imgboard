<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invalid Thread - Imageboard</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
</head>
<body>
    <div class="container">
        <h1>Invalid Thread ID</h1>
        <div class="terms-content" style="text-align: center; margin-bottom: 24px;">
            <p>This thread does not exist or has expired.</p>
        </div>
        <div style="text-align: center;">
            <a href="index.php" class="btn">Back to Home</a>
        </div>
    </div>
</body>
</html>
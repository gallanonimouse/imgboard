<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imageboard</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
</head>
<body>
    <div class="container">
            <h1>Create a New Thread</h1>
            <form action="index.php?op=newthread" method="post" enctype="multipart/form-data" class="create-thread-form">
                <div class="form-group">
                    <label for="thread_name">Thread Name:</label>
                    <input type="text" id="thread_name" name="thread_name" required>
                </div>

                <div class="form-group">
                    <label for="expires_at">Expires At:</label>
                    <select id="expires_at" name="expires_at" required>
                        <option value="15min">15 minutes</option>
                        <option value="1h">1 hour</option>
                        <option value="3h">3 hours</option>
                        <option value="6h">6 hours</option>
                        <option value="1d">1 day</option>
                        <option value="2d">2 days</option>
                        <option value="7d">7 days</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_public" value="1" checked>
                        Public thread (visible on main page)
                    </label>
                </div>
                
                <div class="form-group" id="password_protect_group" style="display: none;">
                    <label for="thread_password">Thread Password:</label>
                    <input type="password" id="thread_password" name="thread_password" placeholder="Enter password to protect this private thread">
                </div>
                
               <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_stamped" value="1" checked>
                        Protect by stamp
                    </label>
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_freezing" value="1" id="is_freezing">
                        Freezing (inactivity timeout)
                    </label>
                </div>

                <div class="form-group" id="freezing_time_group" style="display: none;">
                    <label for="freezing_minutes">Inactivity timeout (minutes):</label>
                    <input type="number" id="freezing_minutes" name="freezing_minutes" min="1" value="5" placeholder="Minutes of inactivity">
                </div>


                <div class="form-group">
                     <label for="message">Initial Message:</label>
                    <textarea id="message" name="message" required></textarea>
                </div>

                <div class="form-group">
                     <label for="image">Attach Image (Optional):</label>
                    <input type="file" name="image" accept=".jpg, .jpeg">
                </div>

                <button type="submit">Create Thread</button>
            </form>
            <a href="index.php" class="btn">Back to All Threads</a>
  
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const isPublicCheckbox = document.querySelector('input[name="is_public"]');
            const passwordGroup = document.getElementById('password_protect_group');
            const passwordInput = document.getElementById('thread_password');

            function togglePasswordVisibility() {
                if (isPublicCheckbox.checked) {
                    passwordGroup.style.display = 'none';
                    passwordInput.removeAttribute('required');
                    passwordInput.value = '';
                } else {
                    passwordGroup.style.display = 'block';
                    passwordInput.setAttribute('required', 'required');
                }
            }

            isPublicCheckbox.addEventListener('change', togglePasswordVisibility);
            togglePasswordVisibility(); // Run on load

            const freezingCheckbox = document.getElementById('is_freezing');
            const freezingTimeGroup = document.getElementById('freezing_time_group');

            function toggleFreezingVisibility() {
                if (freezingCheckbox.checked) {
                    freezingTimeGroup.style.display = 'block';
                } else {
                    freezingTimeGroup.style.display = 'none';
                }
            }

            freezingCheckbox.addEventListener('change', toggleFreezingVisibility);
            toggleFreezingVisibility();
        });
    </script>
</body>
</html>

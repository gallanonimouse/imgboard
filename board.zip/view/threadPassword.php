<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Required - Imageboard</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
</head>
<body>
    <div class="container">
        <h1>Password Required</h1>
        
        <div class="terms-content" style="text-align: center; margin-bottom: 24px;">
            <p>This thread is private and protected by a password. Please enter the password to view the content.</p>
        </div>

        <?php if (isset($password_error) && $password_error): ?>
            <div class="error" style="margin: 0 32px 24px; text-align: center;">
                Incorrect password. Please try again.
            </div>
        <?php endif; ?>

        <form method="POST" action="index.php?thread=<?php echo htmlspecialchars($threadId); ?>" class="terms-form">
            <div class="form-group" style="margin-bottom: 24px;">
                <label for="thread_password">Password:</label>
                <input type="password" id="thread_password" name="thread_password" required placeholder="Enter thread password">
            </div>
            <button type="submit" class="btn" style="margin: 0;">Access Thread</button>
            <a href="index.php" class="btn" style="margin-left: 15px; background: transparent; border: 1px solid var(--primary-color); color: #a5b4fc;">Back to All Threads</a>
        </form>
    </div>
</body>
</html>

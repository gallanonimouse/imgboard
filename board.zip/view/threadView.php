<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imageboard</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
    <style>
        .post-image img {
            cursor: pointer;
            transition: opacity 0.2s ease;
        }

        .post-image img:hover {
            opacity: 0.85;
        }

        #image-lightbox {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.85);
            z-index: 1000;
            justify-content: center;
            align-items: center;
            padding: 1.5rem;
            box-sizing: border-box;
        }

        #image-lightbox.visible {
            display: flex;
        }

        #image-lightbox img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            border-radius: 6px;
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5);
        }

        #lightbox-close {
            position: absolute;
            top: 1.25rem;
            right: 1.25rem;
            width: 2.5rem;
            height: 2.5rem;
            font-size: 2rem;
            line-height: 1;
            color: #fff;
            background: rgba(0, 0, 0, 0.6);
            border: 1px solid rgba(255, 255, 255, 0.4);
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
        }

        #lightbox-close:hover {
            background: rgba(0, 0, 0, 0.8);
        }

        body.lightbox-open {
            overflow: hidden;
        }
    </style>
</head>
<body>
    <div class="container">
            <!-- Display specific thread -->
            <h1>Thread: <?php echo htmlspecialchars($thread['data']['thread_name']); ?></h1>
            
            <!-- Expiration countdown -->
            <div class="thread-expiration">
                <?php 
                $expires_timestamp = strtotime($thread['data']['expires']);
                $remaining_seconds = $expires_timestamp - time();
                if ($remaining_seconds > 0): ?>
                    <span class="expiration-label">Thread expires in:</span>
                    <span class="expiration-timer" id="expiration-timer">
                        <?php echo formatTimeRemaining($remaining_seconds); ?>
                    </span>
                <?php else: ?>
                    <span class="expired">This thread has expired</span>
                <?php endif; ?>
            </div>
            
            <?php $freezingMinutes = (int)($thread['data']['freezing_minutes'] ?? 0); ?>
            <?php if ($freezingMinutes > 0): ?>
                <div class="thread-freezing">
                    <span class="freezing-label">&#10052; This thread requires active participation.</span>
                    <span class="freezing-timer-container">
                        Freeze in: <span class="freezing-timer" id="freezing-timer"><?php echo formatTimeRemaining($freezingMinutes * 60); ?></span>
                    </span>
                </div>
            <?php endif; ?>

            <div class="active-users">
                <span id="active-users-count">Loading...</span> users viewing this thread
            </div>
            
            <a href="index.php" class="btn">Back to All Threads</a>
            <?php if (empty($thread['_share_password'])): ?>
                <button id="copy-link-btn" class="btn" style="background: var(--primary-color); border: 1px solid var(--primary-color);">&#128203; Copy link</button>
            <?php endif; ?>
            
            <div class="thread-content" id="thread-content">
                <?php if (!empty($thread['data']['messages'])): ?>
                    <?php foreach ($thread['data']['messages'] as $message): ?>
                        <div class="post" id="p<?php echo $message['timestamp']; ?>">
                            <div class="post-header">
                                <span class="post-nick"><?php echo htmlspecialchars($message['nick']); ?></span>
                                <a href="#p<?php echo $message['timestamp']; ?>" 
                                   class="post-id" 
                                   data-timestamp="<?php echo $message['timestamp']; ?>">#<?php echo $message['timestamp']; ?></a>
                            </div>
                            
                            <div class="post-content">
                                <p><?php 
                                    // Replace #timestamp with anchor links
                                    $pattern = '/#(\d{10})/';
                                    $replacement = '<a href="#p$1" class="post-ref">#$1</a>';
                                    echo preg_replace($pattern, $replacement, nl2br(htmlspecialchars($message['message'])));
                                ?></p>
                                 <?php if (!empty($message['image'])): ?>
                                     <div class="post-image">
                                         <?php if (!empty($thread['data']['password_hash'])): ?>
                                             <img src="index.php?op=viewimage&thread=<?php echo htmlspecialchars($thread['id']); ?>&image=<?php echo htmlspecialchars($message['image']); ?>" 
                                                  alt="Post image" 
                                                  loading="lazy">
                                         <?php else: ?>
                                             <img src="threads/<?php echo htmlspecialchars($thread['id']); ?>/<?php echo htmlspecialchars($message['image']); ?>" 
                                                  alt="Post image" 
                                                  onerror="this.style.display='none'">
                                         <?php endif; ?>
                                     </div>
                                 <?php endif; ?>
                            </div>
                            <div class="post-meta">
                                <small>Posted: <?php echo date('Y-m-d H:i:s', $message['timestamp']); ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No posts in this thread yet.</p>
                <?php endif; ?>
            </div>
           <!-- Add new post form for existing thread -->
            <div class="add-post-form">
                <h3>Add New Post</h3>
                <form action="index.php?op=addpost&thread=<?php echo htmlspecialchars($thread['id']); ?>" 
                      method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="message">Message:</label>
                        <textarea id="message" name="message" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="image">Attach Image (Optional):</label>
                        <input type="file" name="image"  accept=".jpg, .jpeg">
                    </div>
                    <button type="submit">Add Post</button>
                </form>
                <div class="current-nick">
                    Your nickname: <strong><?php echo htmlspecialchars($_COOKIE['user_nick'] ?? 'Anonymous'); ?></strong>
                </div>
            </div>
            
            <!-- Auto-refresh controls (only shown when JS is enabled) -->
            <div class="auto-refresh" id="auto-refresh" style="display:none;">
                <div class="status-indicator">
                    <div class="status-dot"></div>
                    <span>Auto-refresh: <span id="refresh-status">ON</span></span>
                </div>
                <button id="toggle-refresh" class="toggle-refresh">Pause</button>
            </div>
    </div>

    <script>
        // HTML Escaping utility to prevent XSS
        function escapeHTML(str) {
            if (!str) return '';
            return str.replace(/[&<>'"]/g, 
                tag => ({
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    "'": '&#39;',
                    '"': '&quot;'
                }[tag] || tag)
            );
        }

        // Helper function to format time
        function formatTime(seconds) {
            // Round to whole seconds
            const totalSeconds = Math.floor(seconds);
            
            const days = Math.floor(totalSeconds / 86400);
            const hours = Math.floor((totalSeconds % 86400) / 3600);
            const minutes = Math.floor((totalSeconds % 3600) / 60);
            const secs = totalSeconds % 60;
            
            if (days > 0) {
                return `${days}d ${hours}h ${minutes}m`;
            } else if (hours > 0) {
                return `${hours}h ${minutes}m ${secs}s`;
            } else if (minutes > 0) {
                return `${minutes}m ${secs}s`;
            } else {
                return `${secs}s`;
            }
        }
        
        // Minimal JS only for post ID insertion and countdown
        document.addEventListener('DOMContentLoaded', function() {
            // Store original title for notification feature
            const originalTitle = document.title;
            let hasUnreadMessages = false;
            
            // Function to play subtle notification sound
            function playNotificationSound() {
                try {
                    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                    const oscillator = audioContext.createOscillator();
                    const gainNode = audioContext.createGain();
                    
                    oscillator.connect(gainNode);
                    gainNode.connect(audioContext.destination);
                    
                    // Subtle two-tone notification
                    oscillator.frequency.setValueAtTime(600, audioContext.currentTime);
                    oscillator.frequency.setValueAtTime(800, audioContext.currentTime + 0.1);
                    oscillator.type = 'sine';
                    
                    gainNode.gain.setValueAtTime(0.08, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
                    
                    oscillator.start(audioContext.currentTime);
                    oscillator.stop(audioContext.currentTime + 0.3);
                } catch (e) {
                    console.log('Audio notification failed');
                }
            }
            
            // Restore title when user focuses the tab
            window.addEventListener('focus', function() {
                if (hasUnreadMessages) {
                    document.title = originalTitle;
                    hasUnreadMessages = false;
                }
            });
            
            // Countdown timer
            const expiresTimestamp = <?php echo strtotime($thread['data']['expires']); ?>;
            const timerElement = document.getElementById('expiration-timer');
            
            if (timerElement && expiresTimestamp > Date.now() / 1000) {
                function updateCountdown() {
                    const now = Date.now() / 1000;
                    const remaining = Math.max(0, expiresTimestamp - now);
                    
                    if (remaining <= 0) {
                        timerElement.textContent = 'Expired';
                        timerElement.className = 'expired';
                        return;
                    }
                    
                    timerElement.textContent = formatTime(remaining);
                }
                
                updateCountdown();
                const countdownInterval = setInterval(updateCountdown, 1000);
                
                // Clean up on page unload
                window.addEventListener('beforeunload', () => {
                    clearInterval(countdownInterval);
                });
            }

            // Freezing countdown timer
            const freezingMinutes = <?php echo (int)($thread['data']['freezing_minutes'] ?? 0); ?>;
            const freezingTimerEl = document.getElementById('freezing-timer');

            if (freezingTimerEl && freezingMinutes > 0) {
                if (typeof window.freezingLastActivity === 'undefined') {
                    window.freezingLastActivity = Math.floor(Date.now() / 1000);
                }

                function updateFreezingCountdown() {
                    const now = Math.floor(Date.now() / 1000);
                    const elapsed = now - window.freezingLastActivity;
                    const remaining = Math.max(0, freezingMinutes * 60 - elapsed);

                    if (remaining <= 0) {
                        freezingTimerEl.textContent = 'Frozen';
                        freezingTimerEl.className = 'freezing-timer frozen';
                        window.location.href = 'index.php?op=freezing&thread=' + <?php echo json_encode($thread['id']); ?>;
                        return;
                    }

                    freezingTimerEl.textContent = formatTime(remaining);
                }

                updateFreezingCountdown();
                const freezingCountdownInterval = setInterval(updateFreezingCountdown, 1000);

                window.addEventListener('beforeunload', () => {
                    clearInterval(freezingCountdownInterval);
                });
            }

            // Keep existing auto-refresh functionality
            const threadId = <?php echo json_encode($thread['id']); ?>;
            let lastTimestamp = <?php echo !empty($thread['data']['messages']) 
                ? max(array_column($thread['data']['messages'], 'timestamp')) 
                : 0; ?>;
            let autoRefreshEnabled = true;
            let refreshInterval;

            // Handle post ID clicks
            const messageField = document.getElementById('message');

            function insertMessageReference(timestamp) {
                const reference = '#' + timestamp + ' ';
                const start = messageField.selectionStart || messageField.value.length;
                const end = messageField.selectionEnd || messageField.value.length;
                const text = messageField.value;

                messageField.value = text.substring(0, start) + reference + text.substring(end);
                messageField.focus();
                messageField.setSelectionRange(start + reference.length, start + reference.length);
            }

            function attachPostIdHandler(link) {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    insertMessageReference(this.dataset.timestamp);
                });
            }

            document.querySelectorAll('.post-id').forEach(attachPostIdHandler);

            function showNotification(message, isError = false) {
                let notification = document.getElementById('realtime-notification');
                if (!notification) {
                    notification = document.createElement('div');
                    notification.id = 'realtime-notification';
                    notification.className = 'notification';
                    document.body.appendChild(notification);
                }

                notification.textContent = message;
                notification.classList.toggle('error', isError);
                notification.style.display = 'block';
                notification.style.opacity = '1';

                if (notification.hideTimeout) {
                    clearTimeout(notification.hideTimeout);
                }

                notification.hideTimeout = setTimeout(() => {
                    notification.style.opacity = '0';
                    notification.hideTimeout = setTimeout(() => {
                        notification.style.display = 'none';
                    }, 300);
                }, 3000);
            }

            function scrollToPost(post) {
                if (!post) return;

                const scrollBehavior = window.matchMedia('(prefers-reduced-motion: reduce)').matches
                    ? 'auto'
                    : 'smooth';

                requestAnimationFrame(() => {
                    post.scrollIntoView({ behavior: scrollBehavior, block: 'start' });
                });
            }

            function createPostElement(msg, isPrivate) {
                const postDiv = document.createElement('div');
                postDiv.className = 'post';
                postDiv.id = 'p' + msg.timestamp;

                let imgHtml = '';
                if (msg.image) {
                    const image = encodeURIComponent(msg.image);
                    const imgSrc = isPrivate
                        ? `index.php?op=viewimage&thread=${encodeURIComponent(threadId)}&image=${image}`
                        : `threads/${encodeURIComponent(threadId)}/${image}`;
                    imgHtml = `
                        <div class="post-image">
                            <img src="${imgSrc}" 
                                 alt="Post image" 
                                 onerror="this.style.display='none'">
                        </div>
                    `;
                }

                const escapedMsg = escapeHTML(msg.message);
                const processedMessage = escapedMsg
                    .replace(/\n/g, '<br>')
                    .replace(/#(\d{10})/g, '<a href="#p$1" class="post-ref">#$1</a>');

                const escapedNick = escapeHTML(msg.nick || 'Anonymous');

                postDiv.innerHTML = `
                    <div class="post-header">
                        <span class="post-nick">${escapedNick}</span>
                        <a href="#p${msg.timestamp}" class="post-id" data-timestamp="${msg.timestamp}">#${msg.timestamp}</a>
                    </div>
                    <div class="post-content">
                        <p>${processedMessage}</p>
                        ${imgHtml}
                    </div>
                    <div class="post-meta">
                        <small>Posted: ${new Date(msg.timestamp * 1000).toLocaleString()}</small>
                    </div>
                `;

                attachPostIdHandler(postDiv.querySelector('.post-id'));
                return postDiv;
            }

            function appendMessage(msg, isPrivate) {
                const container = document.getElementById('thread-content');
                if (!container) return null;

                // The post may have arrived through auto-refresh already
                const existingPost = document.getElementById('p' + msg.timestamp);
                if (existingPost) return existingPost;

                const postDiv = createPostElement(msg, isPrivate);
                container.appendChild(postDiv);
                return postDiv;
            }

            function fetchNewMessages() {
                fetch(`index.php?op=getthreadjson&thread=${threadId}&_=${Date.now()}`)
                    .then(response => response.json())
                    .then(data => {
                        const newMessages = data.messages.filter(msg => msg.timestamp > lastTimestamp);
                        if (newMessages.length > 0) {
                            lastTimestamp = Math.max(...newMessages.map(m => m.timestamp));

                            const appendedPosts = newMessages
                                .map(msg => appendMessage(msg, !!data.password_hash))
                                .filter(Boolean);

                            if (appendedPosts.length > 0) {
                                // Auto-scroll to the newest message (no manual scrolling needed)
                                scrollToPost(appendedPosts[appendedPosts.length - 1]);
                                showNotification(`Loaded ${appendedPosts.length} new message(s)`);
                            }

                            // If tab is not focused, show asterisk in title and play sound
                            if (document.hidden) {
                                hasUnreadMessages = true;
                                document.title = '* ' + originalTitle;
                                playNotificationSound();
                            }
                        }
                    })
                    .catch(console.error);
            }

            // Submit new posts (with an optional image) without reloading the page
            const addPostForm = document.querySelector('.add-post-form form');
            if (addPostForm) {
                addPostForm.addEventListener('submit', async function(e) {
                    e.preventDefault();

                    const submitButton = addPostForm.querySelector('button[type="submit"]');
                    const originalButtonText = submitButton ? submitButton.textContent : '';

                    if (submitButton) {
                        submitButton.disabled = true;
                        submitButton.textContent = 'Posting...';
                    }

                    try {
                        const response = await fetch(addPostForm.action, {
                            method: 'POST',
                            body: new FormData(addPostForm),
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest',
                                'Accept': 'application/json'
                            },
                            credentials: 'same-origin'
                        });

                        const contentType = response.headers.get('content-type') || '';
                        const data = contentType.includes('application/json')
                            ? await response.json()
                            : null;

                        if (!response.ok || !data || data.success !== true) {
                            throw new Error(data && data.error
                                ? data.error
                                : 'Could not add the post. Please try again.');
                        }

                        const addedPost = appendMessage(data.message, !!data.password_hash);
                        lastTimestamp = Math.max(lastTimestamp, data.message.timestamp);
                        addPostForm.reset();

                        if (addedPost) {
                            scrollToPost(addedPost);
                        }

                        showNotification('Post added');
                    } catch (error) {
                        showNotification(error.message || 'Could not add the post. Please try again.', true);
                    } finally {
                        if (submitButton) {
                            submitButton.disabled = false;
                            submitButton.textContent = originalButtonText;
                        }
                    }
                });
            }

            function toggleAutoRefresh() {
                autoRefreshEnabled = !autoRefreshEnabled;
                const status = document.getElementById('refresh-status');
                const button = document.getElementById('toggle-refresh');
                
                if (autoRefreshEnabled) {
                    status.textContent = 'ON';
                    button.textContent = 'Pause';
                    startAutoRefresh();
                } else {
                    status.textContent = 'OFF';
                    button.textContent = 'Resume';
                    if (refreshInterval) clearInterval(refreshInterval);
                }
            }
 
            function startAutoRefresh() {
                if (refreshInterval) clearInterval(refreshInterval);
                // 7 sekund gdy zakładka aktywna, 20 sekund gdy nieaktywna
                const interval = document.hidden ? 20000 : 7000;
                refreshInterval = setInterval(fetchNewMessages, interval);
            }
 
            if (typeof threadId !== 'undefined' && expiresTimestamp > Date.now() / 1000) {
                document.getElementById('auto-refresh').style.display = 'flex';
                document.getElementById('toggle-refresh').addEventListener('click', toggleAutoRefresh);
                startAutoRefresh();
                
                document.addEventListener('visibilitychange', () => {
                    if (!autoRefreshEnabled) return;
                    
                    // Restart interval with new timing
                    if (refreshInterval) clearInterval(refreshInterval);
                    
                    if (document.hidden) {
                        // Zakładka nieaktywna: 20 sekund
                        refreshInterval = setInterval(fetchNewMessages, 20000);
                    } else {
                        // Zakładka aktywna: 7 sekund
                        refreshInterval = setInterval(fetchNewMessages, 7000);
                        // Pobierz od razu po powrocie
                        fetchNewMessages();
                    }
                });
            }
        });
    </script>
    <!-- Image lightbox overlay (rendered before the script so getElementById works) -->
    <div id="image-lightbox">
        <img id="lightbox-img" src="" alt="Full image">
        <button id="lightbox-close" type="button" aria-label="Close">&times;</button>
    </div>

    <script>
// User activity tracking
const threadId = <?php echo json_encode($thread['id']); ?>;
const userId = localStorage.getItem('user_id') || Math.random().toString(36).substr(2, 9);
localStorage.setItem('user_id', userId);

// Function to update activity
async function updateActivity() {
    try {
        await fetch('active_users.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                thread_id: threadId,
                user_id: userId,
                action: 'heartbeat'
            })
        });
    } catch (e) {
        console.log('Activity tracking failed');
    }
}

// Function to remove user when leaving the page (uses keepalive to ensure execution)
function removeUser() {
    fetch('active_users.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        keepalive: true,
        body: JSON.stringify({
            thread_id: threadId,
            user_id: userId,
            action: 'leave'
        })
    });
}

// Update activity status every 30 seconds
updateActivity();
setInterval(updateActivity, 30000);

// Remove user when leaving the page
window.addEventListener('beforeunload', removeUser);
window.addEventListener('unload', removeUser);

// Monitor tab visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        removeUser();
    } else {
        updateActivity();
    }
});

// Freezing logic - redirect to freezing page on inactivity
const freezingMinutes = <?php echo (int)($thread['data']['freezing_minutes'] ?? 0); ?>;

if (freezingMinutes > 0) {
    if (typeof window.freezingLastActivity === 'undefined') {
        window.freezingLastActivity = Math.floor(Date.now() / 1000);
    }

    function checkFreezing() {
        const now = Math.floor(Date.now() / 1000);
        const elapsed = now - window.freezingLastActivity;
        if (elapsed > freezingMinutes * 60) {
            window.location.href = 'index.php?op=freezing&thread=' + threadId;
        }
    }

    // Check every 30 seconds
    setInterval(checkFreezing, 30000);

    // Reset on form submission
    document.querySelector('.add-post-form form')?.addEventListener('submit', function() {
        window.freezingLastActivity = Math.floor(Date.now() / 1000);
    });
}

// Fetch and display active users count
async function updateUsersCount() {
    try {
        const response = await fetch('active_users.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                thread_id: threadId,
                user_id: userId,
                action: 'heartbeat'
            })
        });
        const data = await response.json();
        document.getElementById('active-users-count').textContent = data.active_users;
    } catch (e) {
        // Do not show errors
    }
}

// Run checks immediately on startup
updateUsersCount();
setInterval(updateUsersCount, 30000);

// --- In-thread image lightbox (click thumbnail -> full size) ---
const lightboxEl = document.getElementById('image-lightbox');
const lightboxImgEl = document.getElementById('lightbox-img');
const lightboxCloseBtn = document.getElementById('lightbox-close');

function openLightbox(src) {
    if (!lightboxEl || !lightboxImgEl) return;
    lightboxImgEl.src = src;
    lightboxEl.classList.add('visible');
    document.body.classList.add('lightbox-open');
}

function closeLightbox() {
    if (!lightboxEl || !lightboxImgEl) return;
    lightboxEl.classList.remove('visible');
    lightboxImgEl.src = '';
    document.body.classList.remove('lightbox-open');
}

if (lightboxEl) {
    lightboxEl.addEventListener('click', function (e) {
        if (e.target === lightboxEl) {
            closeLightbox();
        }
    });
}

if (lightboxCloseBtn) {
    lightboxCloseBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        closeLightbox();
    });
}

document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
        closeLightbox();
    }
});

// Delegate clicks on in-thread images (works for server-rendered and auto-refreshed posts)
const threadContentEl = document.getElementById('thread-content');
if (threadContentEl) {
    threadContentEl.addEventListener('click', function (e) {
        const img = e.target.closest('.post-image img');
        if (!img || !img.src) return;
        e.preventDefault();
        openLightbox(img.src);
    });
}

// --- Copy thread link to clipboard ---
const copyBtn = document.getElementById('copy-link-btn');
const sharePassword = <?php echo json_encode($thread['_share_password'] ?? null); ?>;

if (copyBtn) {
    copyBtn.addEventListener('click', async function() {
        const baseUrl = window.location.origin + window.location.pathname + '?thread=' + encodeURIComponent(threadId);
        const shareUrl = sharePassword
            ? baseUrl + '&password=' + encodeURIComponent(sharePassword)
            : baseUrl;

        try {
            await navigator.clipboard.writeText(shareUrl);
            const originalText = copyBtn.textContent;
            copyBtn.textContent = 'Copied!';
            copyBtn.style.background = 'var(--success-color, #22c55e)';
            setTimeout(() => {
                copyBtn.textContent = originalText;
                copyBtn.style.background = 'var(--primary-color)';
            }, 2000);
        } catch (err) {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = shareUrl;
            textArea.style.position = 'fixed';
            textArea.style.left = '-9999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            try {
                document.execCommand('copy');
                copyBtn.textContent = 'Copied!';
                setTimeout(() => { copyBtn.textContent = '&#128203; Copy link'; }, 2000);
            } catch (e) {
                console.error('Copy failed', e);
            }
            document.body.removeChild(textArea);
        }
    });
}
</script>
</body>
</html>

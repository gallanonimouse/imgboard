<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Key for encrypting sensitive data (e.g. IP)
define('SECRET_KEY', "yavedi");

// File used by the moderator panel to store private notes about IP addresses.
// The path is relative to the board root directory. Notes never ban an IP.
define('IP_NOTES_FILE', 'ipnotes.json');

// Maximum image height in pixels
define('MAX_IMAGE_HEIGHT', 800);  // You can change this value

// Whether images should be scaled when they exceed MAX_IMAGE_HEIGHT
define('SHOULD_SCALE_IMAGE', true); // true - scale, false - no scaling

$nicks = [
    'AnonOne',
    'AnonTwo',
    'AnonThree',
    'SilentUser',
    'QuietUser',
    'HiddenUser',
    'PrivateUser',
    'PublicUser',
    'GuestOne',
    'GuestTwo',
    'GuestThree',
    'NightGuest',
    'DayGuest',
    'BrowserOne',
    'BrowserTwo',
    'DailyBrowser',
    'NightBrowser',
    'WebSurfer',
    'NetSurfer',
    'NetWalker',
    'DigitalNomad',
    'UrbanNomad',
    'CalmWanderer',
    'LostWanderer',
    'FreeWanderer',
    'ObserverOne',
    'ObserverTwo',
    'SilentObserver',
    'DeepObserver',
    'FastReader',
    'SlowReader',
    'QuietReader',
    'ActiveReader',
    'ThinkerOne',
    'ThinkerTwo',
    'DeepThinker',
    'OpenThinker',
    'SharpMind',
    'CalmMind',
    'CuriousMind',
    'NeutralMind',
    'WriterOne',
    'WriterTwo',
    'QuietWriter',
    'PublicWriter',
    'PosterOne',
    'PosterTwo',
    'LatePoster',
    'EarlyPoster',
    'CommentatorOne',
    'CommentatorTwo',
    'SilentCommentator',
    'ActiveCommentator',
    'ContributorOne',
    'ContributorTwo',
    'PassiveContributor',
    'ActiveContributor',
    'ParticipantOne',
    'ParticipantTwo',
    'SilentParticipant',
    'ActiveParticipant',
    'MemberOne',
    'MemberTwo',
    'NewMember',
    'OldMember',
    'NetizenOne',
    'NetizenTwo',
    'FreeNetizen',
    'ModernNetizen',
    'ForumGhost',
    'ForumShadow',
    'SoftVoice',
    'HardVoice',
    'NeutralVoice',
    'QuietVoice',
    'LurkerOne',
    'LurkerTwo',
    'DeepLurker',
    'CasualLurker',
    'VisitorOne',
    'VisitorTwo',
    'RandomVisitor',
    'RegularVisitor'
];


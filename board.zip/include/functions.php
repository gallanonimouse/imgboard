<?php

/**
 * Encrypts text using AES-256-CBC.
 * The result is Base64 encoded, making it safe for files, databases, etc.
 *
 * @param string $text Text to encrypt
 * @param string $key  Encryption key
 * @return string      Base64 encoded ciphertext
 */
function encryptText(string $text, string $key): string
{
    $cipher = 'aes-256-cbc';
    $ivLength = openssl_cipher_iv_length($cipher);
    
    // Random initialization vector (IV) for each call
    $iv = random_bytes($ivLength);
    
    // AES-256 key must be exactly 32 bytes. Hash it to fit.
    $keyHash = hash('sha256', $key, true);
    
    $encrypted = openssl_encrypt($text, $cipher, $keyHash, OPENSSL_RAW_DATA, $iv);
    if ($encrypted === false) {
        throw new RuntimeException('Failed to encrypt data.');
    }

    // Combine IV with ciphertext and encode in Base64
    return base64_encode($iv . $encrypted);
}

/**
 * Decrypts text encrypted by encryptText().
 *
 * @param string $cipherText Base64 encoded ciphertext
 * @param string $key        Decryption key
 * @return string            Original text
 */
function decryptText(string $cipherText, string $key): string
{
    $cipher = 'aes-256-cbc';
    $ivLength = openssl_cipher_iv_length($cipher);
    
    $keyHash = hash('sha256', $key, true);
    
    $decoded = base64_decode($cipherText, true);
    if ($decoded === false || strlen($decoded) < $ivLength) {
        throw new InvalidArgumentException('Invalid ciphertext format.');
    }

    // Extract IV (first 16 bytes) and the ciphertext
    $iv = substr($decoded, 0, $ivLength);
    $encrypted = substr($decoded, $ivLength);

    $decrypted = openssl_decrypt($encrypted, $cipher, $keyHash, OPENSSL_RAW_DATA, $iv);
    if ($decrypted === false) {
        throw new RuntimeException('Decryption failed. Invalid key or corrupt data.');
    }

    return $decrypted;
}


function formatTimeRemaining($seconds) {
    // Round to whole seconds
    $seconds = floor($seconds);
    
    $days = floor($seconds / 86400);
    $hours = floor(($seconds % 86400) / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $secs = $seconds % 60;
    
    if ($days > 0) {
        return $days . 'd ' . $hours . 'h ' . $minutes . 'm';
    } elseif ($hours > 0) {
        return $hours . 'h ' . $minutes . 'm ' . $secs . 's';
    } elseif ($minutes > 0) {
        return $minutes . 'm ' . $secs . 's';
    } else {
        return $secs . 's';
    }
}

function logThreadAction(string $operation, string $threadid, string $timestamp): void {
    // Get real client IP (considering proxy headers)
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    // Trusted proxy support (optional - for reverse proxy setups)
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Take the first address in the list (most reliable)
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ips[0]);
    } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }

 
    $logFile = __DIR__ . '/../threads/log.txt';

    // Create log entry
    $logLine = "$timestamp:$operation:$threadid:".encryptText($ip,SECRET_KEY)."\n";

    // Append to log file
    file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
}

function getRealIP() {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}



